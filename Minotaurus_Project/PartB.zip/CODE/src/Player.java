//This class is used for the creation of Theseus and Minotaur, the two main players of this game.
//An object of this class has specific labyrithm coordinations, an id, a score if the player is Seus.
//The methods of this class define the movement of the players, which basically is randomly chosen based on the walls created in the map.
import java.util.*;
public class Player {
	int playerId;		//the id of the player
	String name;		//the name of the player
	Board board;		// a board item
	int score;			//the score of the player
	int x;				//x coordinate of the player 
	int y;				//y coordinate of the player

	//the basic constructor of the class.It initialises all the variables(we point out that all these variables are going to be changes
	//inside the game though setters and the methods of the class so these values are temporary).
	public  Player() {
		playerId=0;
		name=new String();
		score=0;
		x=0;
		y=0;
		board=new Board();
	}
	//second constructor
	public Player(int playerId,String name,Board board,int score,int x,int y) {
        this.playerId=playerId;
        this.name=name;
        this.board=board;
        this.score=score;
        this.x=x;
        this.y=y;

    }
	//setter for the variable playerId
	public void setPlayerId(int playerId) {					
		this.playerId = playerId;
	}
	//setter for the variable name
	public void setName(String name) {						
		this.name =  name;
	}
	//setter for the variable board
	public void setBoard(Board board) {
		this.board = board;
	}
	//setter for the variable score
	public void setScore(int score) {						
		this.score = score;
		
	}
	//setter for the variable x
	public void setX(int x) {								
		this.x = x;
	}
	//setter for the variable y
	public void setY(int y) {								
		this.y = y;
	}
	
	
	//getter for the variable playerId
	public int getPlayerId() {								
		return playerId;
	}
	//getter for the variable name
	public String getName() {								
		return name;
	}
	//getter for the variable board
	public Board getBoard() {
		return board;
	}
	//getter for the variable score
	public int getScore() {									
		return score;
	}
	//getter for the variable x
	public int getX() {										
		return x;
	}
	//getter for the variable y
	public int getY() {										
		return y;
	}
	
	//This method is used so as to find and store the possible moves, given the tile that the player is in.
	//To do so we use an ArrayList that stores integers that are linked to a certain direction according to the pdf instructions.
	public ArrayList<Integer> PossibleMoves(Tile tile) {	
		ArrayList<Integer>	Moves = new	ArrayList<Integer>();//this is the ArrayList that will save the integers connected to the moves.
		if(tile.getUp() == false) {
			Moves.add(1);				   //1->UP
		}
		if(tile.getRight() == false) {			//3->RIGHT
			Moves.add(3);
		}
		
		if(tile.getDown() == false) {		    //5->DOWN
			Moves.add(5);
		}
		if(tile.getLeft() == false) {
			Moves.add(7);					//7->LEFT
		}
		
		
		
		return Moves;
	}
	
	//This method is used to randomly choose the move of every player, based on the tile he is in and the walls in the labyrinth.
	//
	public int[] move(int id){
		Tile playerTile = getTile(getX(),getY());//we find the tile that the player is in currently.
		int randomHelper = (int)(Math.random()*PossibleMoves(playerTile).size());// the number of the possible moves.
		int movePlayer = PossibleMoves(playerTile).get(randomHelper);//we get the direction randomly.
		int[] move = new int[4];			//[0]=tileId
											//[1]=X
											//[2]=Y
											//[3]= SUPPLY ID
		switch( movePlayer ){	//here we move the player to the next tile(using its tileId)by changing the x and y coordinates.
			case 1:
				setY(getY() + 1);
				break;
			case 3:
				setX(getX() + 1);
				break;												
			case 5:
				setY(getY() - 1);
				break;
			case 7:
				setX(getX() - 1);
				break;
		}
		move[0] = getTile(getX(),getY()).getTileId();	//[0]=tileId
		move[1] = getX(); //[1]=x
		move[2] = getY();//[2]=y
		Tile[] tiles = board.getTiles();	
		Supply[] supplies = board.getSupplies();	// we use these arrays to know if the player will be in the same tile with
		//a supply so as to change the supplyId and his score.
		if(id == 1) {
			for(int i=0 ; i < supplies.length ; i++ ) {
				if(tiles[playerTile.getTileId()].getTileId() == supplies[i].getsupplyTileId()) { 	
					setScore(getScore()+1	);	//increasing the score by 1.									
					move[3]=supplies[i].getsupplyId();	//[3]= SUPPLY ID							
					System.out.println("YOU GOT A SUPPLY, GOOD JOB");	
					supplies[i].setX(-1);
					supplies[i].setY(-1);
					supplies[i].setsupplyTileId(-1);//changing the variables of the supply so as to be deleted from the map.
					}
				else move[3]=0; //[3]= SUPPLY ID
				}
		}
		else if( id == 2) move[3]=0;
			
		
		if(PossibleMoves(playerTile) == null) {//in case there is no possible move											
			System.out.println("ERROR YOU CANNOT MOVE"); 
	
	
			}
		return move;
		
	}
	//this methods returns the tile,given the x and the y coordinates.
	public Tile getTile(int sx, int sy) {
		Tile[]	tiles=board.getTiles();	//to do so we compare the given x and y with the ones of the tiles of the labyrinth.
		int i=0;                       
		for (;i<tiles.length;i++) {
			
			if((sx == tiles[i].getX()) && (sy == tiles[i].getY())) {
				break;//once the tile is found we can return the tile we searched for.
			}
		}
		return tiles[i];
	}
} 