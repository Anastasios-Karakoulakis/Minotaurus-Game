import java.util.ArrayList;
import java.util.HashMap;

public class HeuristicPlayer extends Player{
	private ArrayList<Integer[]> path;
	private static int totalTimesFront;
	private static int totalTimesLeft;
	private static int totalTimesRight;
	private static int totalTimesBack;
	private int otherPlayer;
	private int currentPos;

	
	
	
	public HeuristicPlayer() {
		super();
	    path= new ArrayList<Integer[]>();
	   
		totalTimesFront=0;
		totalTimesLeft=0;
		totalTimesRight=0;
		totalTimesBack=0;
	    otherPlayer=-1;
        currentPos=0;

	}
	
	public HeuristicPlayer(int playerId,String name,Board board,int score,int x,int y,int otherPlayer) {
		super(playerId,name,board,score,x,y); 
	    path= new ArrayList<Integer[]>();
		totalTimesFront=0;
		totalTimesLeft=0;
		totalTimesRight=0;
		totalTimesBack=0;
		this.otherPlayer=otherPlayer;
	}
	//setters
    public void setPath(ArrayList<Integer[]> path) {
    	this.path=path;
    }
    public void setOtherPlayer(int otherPlayer) {
    	this.otherPlayer=otherPlayer;
    }
    
    public void setCurrentPos(int currentPos) {
    	this.currentPos=currentPos;
    	
    }
    //getters
    public ArrayList<Integer[]> getPath(){
    	return path;
    }
    public int getOtherPlayer() {
    	return otherPlayer;
    }
  
    public int getCurrentPos() {
    	return currentPos;
    }
    /*
     * this method evaluates the dice of the player,
     * it uses the other methods to find the distances
     * if it does not  have an information about the distances it returns 0
     */
	public double evaluate(int dice , int currentPos) {
	
		double minotaurDist=minoDistFinder(dice,currentPos);


    	double supplyDist=supplyDistFinder(dice,currentPos);
  	
    	
        if(minotaurDist==0&&supplyDist==0) {
     
            return 0;
        }
        else if(minotaurDist==0) {
            double f=(4-supplyDist)*0.1;
  
            return f;
        }
        else {
        double f=(4-supplyDist)*0.1-(1/(minotaurDist+1));
  
        return f;
        /* ��� �������� 3: 0.1 /0.225
         *                 2: 0.2/0.3
         *                 1: 0.3/0.45
         */
        }
	}
	/*in this method , we create an ArrayList of DataContainers( calling the dataCollectDice method) that will contain the information of 3 tiles in direction Dice.
	 * then we iterate trough the ArrayList and we search if there is Minotaurus, and if the player can see him( we search if there is wall), if there is wall the player cannot see the Minotaurus
	 * if the player can see the Minoturus we return his distance from him
	 */
	public int minoDistFinder(int dice, int TileId) {
        ArrayList<DataContainer> DataCollection=dataCollectDice(dice,TileId);
        int minoDist=0;
        
        for(int i=0;i<DataCollection.size();i++) {
            
        if(DataCollection.get(i).getWalls().get(oppositeDirection(dice))!=null && DataCollection.get(i).getWalls().get(oppositeDirection(dice))==false){//check for Mino && the opposite wall of the direction
                if(DataCollection.get(i).getMinotaurus()==true ) {                    //check all the items of the DataCollection in serial, returns the distance from the Minotaurus
                    minoDist=i;
            
                    break;
                }
            }
        else break;
        }
    
        return minoDist;
    }
	/*
	 * this method is similar with the minoDistFinder,it is the same ArrayList(with DataCollectDice method) but at this time we search for supplies in the DataContainers
	 * we check again if there is wall, and then search the supply variable of the DataContainers
	 * if there is a supply we return the distance that has the player from the supply
	 */
	public int supplyDistFinder(int dice,int TileId) {
        ArrayList<DataContainer> DataCollection=dataCollectDice(dice,TileId);
        int supplyDist=0;
        for(int i=0;i<DataCollection.size();i++) {
            if(DataCollection.get(i).getWalls().get(oppositeDirection(dice))!=null ) {
          
            	if(DataCollection.get(i).getWalls().get(oppositeDirection(dice))==false) {
            
            	if(DataCollection.get(i).getSupply()==true ) {                    //check all the items of the DataCollection in serial,it returns the closest distance
                    supplyDist=i+1;
            
                    break;
                }
            }
            }
            else break;

        }
        return supplyDist;
    }
    /*
     * this method helps us to search the wanted wall, returns the opposite direction of the dice
     *  +   +   +---+   +---+
		|                   |
		+   +   +   +   +   +
		|         T         |
		+   +   +---+   +   +   
		|       | M         |
		+   +   +   +   +   +   
     *  in the above case if the player wants to search  the dice=5 he must see the wall of the next Tile that is in the direction 1
     *  so we use this function to reverse the direction 
     */
    public int oppositeDirection(int dice) {
        switch(dice) {
        case 1:
            return 5;
        case 3:
            return 7;
        case 5:
            return 1;
        case 7:
            return 3;
        default: return 0;
        }
    }
    /*
     * this method helps us to collect and store the data we want
     * It has an ArrayList of DataContainers, each container has the information about one tile of  wanted direction
     * this method calls the needed methods of DataContainer class in order to collect the data
     */
    public ArrayList<DataContainer> dataCollectDice(int dice, int TileId) {
    	ArrayList<DataContainer> tilesInfo= new ArrayList<DataContainer>();
    	for(int recursive=0;recursive<3;recursive++) {
	    	tilesInfo.add(new DataContainer());				//initialize the ArrayList with 3 data Container for MAX  3 Tiles
		    	if(diceToTile(dice,TileId,0)!=-1) {
		    		
		    		tilesInfo.get(recursive).setTileId(diceToTile(dice,TileId,recursive));
		    
		    		tilesInfo.get(recursive).DataCollector(board,otherPlayer); // we collect all the data about the 3 tiles
		    	}
		    	else break;
    	}
    	return tilesInfo;
    }
    /*
     * this method is a recursive method, takes as arguments the dice, the TileId of the player and the number of walls we want to search-1( this is the recursive counter)
     * for recursiveCounyer=0 it will return the Tile Id of the first Tile in the direction we want to search
     * for recursiveCounyer=1 it will return the Tile Id of the second Tile in the direction we want to search,and  so go on
     *  it calls the method nextTileAcceptableTileId, in order to check if it is acceptable the Tile Id that will return 
     */
    public int diceToTile(int dice, int TileId, int recursiveCounter) {
    	int newTileId=TileId;															//this is the value if the TileId is not acceptable
    	if(nextTileAcceptableTileId(dice,TileId)==true) {
	    	switch(dice) {
		    	case 1:
		    		newTileId=TileId+board.getN();									//above tile
		    		break;
		    	case 3:
		    		newTileId=TileId+1;												//right tile
		    		break;
		    	case 5:
		    		newTileId=TileId-board.getN();									//down tile
		    		break;
		    	case 7:
		    		newTileId=TileId-1;												//left tile
		    		break;
	    	}
	    	if(recursiveCounter>0) {
	    		return diceToTile(dice,newTileId,recursiveCounter-1);				//here it calls itself to get the next tile in the DICE direction
	    	}
	    	else return newTileId;
    	}
    	else return newTileId;
    }
    
    /*
     * this method checks if is acceptable the Tile Id of the tile we want to search
     * its not acceptable to go to next Tile if the current tile is at the first or last row,or at the first or last column of the board
     */
    public Boolean nextTileAcceptableTileId(int dice,int TileId) {
    	Boolean nextTileExists=true;
    	switch(dice) {
    	case 1:													// check is at the top
    		if(TileId+board.getN()>=board.getN()*board.getN()) {   //we check if the above tile , exists, if it has Id bigger than N*N it is out of bounds
    			nextTileExists=false;
    		}
    		break;
    	case 3:
    		if(TileId%board.getN()==(board.getN()-1)) {					//checks if it is in the last right column
    			nextTileExists=false;
    		}
    		break;
    	case 5:
    		if(TileId-board.getN()<0) {							//checks if it is at the at the first row
    			nextTileExists=false;
    		}
    		break;
    	case 7:
    		if(TileId%board.getN()==0) {						//checks if its at the first left column
    			nextTileExists=false;
    		}
    		break;
    	}
    	return nextTileExists;
    	
    }
    
	
    /* The function getNextMove is used to scan the possible moves our HeristicPlayer can do by using the inherited function PossibleMoves and then evaluating every single one of them by using the 
     * evaluation function. Then, we take the move with the best evaluation or in case that every single one has the default value we take a random move. We then set the elements of the current path variable
     * which is used to renew the class variable path. 
     */
    	public int getNextMove(int currentPos) {
    		/* This Hashmap is used to store and connect an evaluation with a TileId so that in the end using as a key the maxEvaluation we take the tileId of the next tile our player will be.
    		*/
    		HashMap <Double,Integer> h2=new HashMap<Double,Integer>();
    		HashMap <Double,Integer> h3=new HashMap<Double,Integer>();//This hashmap is used to connect an evaluation with a dice so that we can renew the path variable knowing the maxEvaluation variable.
    		ArrayList <Integer> moves= new ArrayList<Integer>(); //this ArrayList is used to call and store the PossibleMoves ArrayList which gives us where Theseus can go(no wall) given the current tile.
    		Integer[] currentPath=new Integer[4];
    		moves=PossibleMoves(board.getTiles()[currentPos]);// now we see from the current posisiton of the Theseus where he can move.
    		int i=0;
    		double maxEvaluation=-10.0;// this variable is use to store the maximum evalution. With our function evaluation will take a number between -1 and 1.
    		int evaluationCounter=0; // this counter is used to know how many possible moves can be done given current Position.
    		
    		Supply[] supplies=board.getSupplies();
    		for(int j=0 ; j < supplies.length ; j++ ) {
    			
    			if(currentPos == supplies[j].getsupplyTileId()) { 
    				setScore(getScore()+1);	//increasing the score by 1.									
					//move[3]=supplies[i].getsupplyId();	//[3]= SUPPLY ID							
					System.out.println("YOU GOT A SUPPLY, GOOD JOB: "+getScore());
					currentPath[1]=1;
    				supplies[j].setX(-1);
    				supplies[j].setY(-1);
    				supplies[j].setsupplyTileId(-1);		//changing the variables of the supply so as to be deleted from the map.
    				break;
    				}
    			else {
					 //[3]= SUPPLY ID
					currentPath[1]=0;
				 }
    			
    			}
    	
    		
    	
    		
    		while( i <moves.size()) {
    			int helper1;								//in helper1 is the next tile id
    			double helper2;								//in helper2 is the evaluation of a certain move
    			switch(moves.get(i)) {
    			case 1://up
    				helper1=currentPos+board.getN();
    				helper2=evaluate(1,currentPos);
    				if(helper2==0) {
    					evaluationCounter++;
    				}
    				if(helper2>maxEvaluation) {
    					maxEvaluation=helper2;
    				}
    				h2.put(helper2,helper1);
    				h3.put(helper2, 1);
    				break;
    			case 3://right
    				helper1=currentPos+1;
    				helper2=evaluate(3,currentPos);
    				if(helper2==0) {
    					evaluationCounter++;
    				}
    				if(helper2>maxEvaluation) {
    					maxEvaluation=helper2;
    				}
    				h2.put(helper2, helper1);
    				h3.put(helper2, 3);
    				break;
    			case 5://down
    				helper1=currentPos-board.getN();
    				helper2=evaluate(5,currentPos);
    				if(helper2==0) {
    					evaluationCounter++;
    				}
    				if(helper2>maxEvaluation) {
    					maxEvaluation=helper2;
    				}
    				h2.put(helper2,helper1);
    				h3.put(helper2, 5);
    				break;
    			case 7://left
    				helper1=currentPos-1;
    				helper2=evaluate(7,currentPos);
    				if(helper2==0) {
    					evaluationCounter++;
    				}
    				if(helper2>maxEvaluation) {
    					maxEvaluation=helper2;
    				}
    				h2.put(helper2, helper1);
    				h3.put(helper2, 7);
    				break;
    			}
    		i++;
    		}
    		if(evaluationCounter==(moves.size())) {				//we play randomly in case that every single evaluation has the default value which in our case is 0
    			Tile playerTile = getTile(getX(),getY());		//we find the tile that the player is in currently.
    			int randomHelper = (int)(Math.random()*moves.size());// the number of the possible moves.
    			int movePlayer = PossibleMoves(playerTile).get(randomHelper);//we get the direction randomly.
    			int[] move = new int[4];						//[0]=tileId
    															//[1]=X
    															//[2]=Y
    			//System.out.println("the random dice is "+ movePlayer);//[3]= SUPPLY ID
    			switch( movePlayer ){	//here we move the player to the next tile(using its tileId)by changing the x and y coordinates.
    				case 1:
    					setY(getY() + 1);
    					totalTimesFront++;
    					currentPath[0]=1;
    					break;
    				case 3:
    					setX(getX() + 1);
    					totalTimesRight++;
    					currentPath[0]=3;
    					break;												
    				case 5:
    					setY(getY() - 1);
    					totalTimesBack++;
    					currentPath[0]=5;
    					break;
    				case 7:
    					setX(getX() - 1);
    					totalTimesLeft++;
    					currentPath[0]=7;
    					break;
    			};
    			move[0] = getTile(getX(),getY()).getTileId();	//[0]=tileId
    			move[1] = getX(); //[1]=x
    			move[2] = getY();//[2]=y
    			move[3]=0;
    			if(PossibleMoves(playerTile) == null) {//in case there is no possible move											
    				System.out.println("ERROR YOU CANNOT MOVE"); 
    				}
    			/*
    			 * Here we know for sure that the labyrinth close to Theseus is empty cause every evaluation was 0.
    			 */
    			//currentPath[1]=0;//because we have already scanned the tiles near our player we know that he cannot take a supply.
    			currentPath[2]=0;//0 is the default value for the supply distance.
    			currentPath[3]=0;//0 is the default value for minotaurus distance.
    			path.add(currentPath);
    			return move[0];
    		}

    		else {
    		currentPath=move(h3.get(maxEvaluation),currentPath);//the move function 
    		//here we renew the current path variable that will be added to the Arraylist.
    		currentPath[0]=h3.get(maxEvaluation);
    		currentPath[2]=supplyDistFinder(h3.get(maxEvaluation),currentPos);
    		currentPath[3]=minoDistFinder(h3.get(maxEvaluation),currentPos);
    		path.add(currentPath);
    		return h2.get(maxEvaluation);
    		}
    	}
    	/*move function is overloaded here because we want this function to be able to add values to the variable currentPath that will be added to 
    	 * the  path member variable. This function basically implements the move,changing x and y variables of the player,updating his score, by taking the dice.
    	 */
    	public Integer[] move(int dice,Integer[] currentPath){
    		Tile playerTile = getTile(getX(),getY());//we find the tile that the player is in currently.
    		int[] move = new int[4];			//[0]=tileId
    											//[1]=X
    											//[2]=Y
    											//[3]= SUPPLY ID
    		switch( dice ){	//here we move the player to the next tile(using its tileId)by changing the x and y coordinates.
    			case 1:
    				setY(getY() + 1);
    				totalTimesFront++;
    				break;
    			case 3:
    				setX(getX() + 1);
    				totalTimesRight++;
    				break;												
    			case 5:
    				setY(getY() - 1);
    				totalTimesBack++;
    				break;
    			case 7:
    				setX(getX() - 1);
    				totalTimesLeft++;
    				break;
    		}
    		move[0] = getTile(getX(),getY()).getTileId();	//[0]=tileId
    		move[1] = getX(); //[1]=x
    		move[2] = getY();//[2]=y

    		
    		
    			

    			
    		if(PossibleMoves(playerTile) == null) {//in case there is no possible move											
    			System.out.println("ERROR YOU CANNOT MOVE"); 
    			}
    		return currentPath;
    		
    	}
    	/* In the functions statistics which is called only in the end of the game we print out information about each and every round, but some information about the total movement of our Heristic Player
    	 * as well. To do so, we use the ArrayList path where every round's information is stored and 4 static variables just to avoid using more loops in this simple function.
    	 */
    	public void statistics(int finalRound) {
    		System.out.println();
    		int localScore=0;
    		for(int counter=0; counter< finalRound ;counter++) {
    		System.out.println("In the "+ (counter+1) +" round of the game Theseus:");
    		if(path.get(counter)[1]==1) {
    			localScore++;
    			System.out.println("1) had gathered "+ localScore + " supplies(until that time).");
    		}
    		else {
    		System.out.println("1) had gathered "+ localScore + " supplies.");
    		}
    		System.out.println("2) was "+ path.get(counter)[2] +" blocks away from the closest supply(reminder:default value is 0)");
    		System.out.println("3) was "+ path.get(counter)[3] +" blocks away from Minotaur(reminder:default value is 0)");
    		System.out.println("-------------------------------------------------");
    		System.out.println();
    		}
    			System.out.println("Total times Theseus went front: " + totalTimesFront);
    			System.out.println("Total times Theseus went back: " + totalTimesBack);
    			System.out.println("Total times Theseus went right: " + totalTimesRight);
    			System.out.println("Total times Theseus went left: " + totalTimesLeft);
    		}
	
}

   

   