
import java.util.ArrayList;
import java.util.Collections;

/**
 * 
 *
 */
public class MinMaxPlayer extends Player {

	private ArrayList<Integer[]> path;
	private static int totalTimesFront=0;
	private static int totalTimesLeft=0;
	private static int totalTimesRight=0;
	private static int totalTimesBack=0;
	private int otherPlayer;
	private int currentPos;
	
	private int pickingSupply=0;

	public MinMaxPlayer() {
		super();
	    path= new ArrayList<Integer[]>();
	
	    otherPlayer=-1;
        currentPos=0;
       
	}

	/**
	 * @param playerId
	 * @param name
	 * @param board
	 * @param score
	 * @param x
	 * @param y
	 */
	public MinMaxPlayer(int playerId, String name, Board board, int score, int x, int y,int otherPlayer) {
		super(playerId, name, board, score, x, y);
		path= new ArrayList<Integer[]>();
		
		currentPos=getTile(x, y).getTileId();
		this.otherPlayer=otherPlayer;
		
		//this.otherPlayer=otherPlayer;
		// TODO Auto-generated constructor stub
	}
	//setters
    public void setPath(ArrayList<Integer[]> path) {
    	this.path=path;
    }
    public void setOtherPlayer(int otherPlayer) {
    	this.otherPlayer=otherPlayer;
    }
    
    public void setCurrentPos(int currentPos) {
    	this.currentPos=currentPos;
    	
    }
   
    //getters
    //  public Node getRoot() {
    //  	return root;
   //   }
      public ArrayList<Integer[]> getPath(){
      	return path;
      }
      public int getOtherPlayer() {
      	return otherPlayer;
      }
    
      public int getCurrentPos() {
      	return currentPos;
      }
  
      public int getNextMove (int currentPos, int opponentCurrentPos) {
    	  /*	Use current board to create a new node which corresponds to the root of the tree.
    	  	Call createMySubtree(root, 1,..)
    	  	// The tree is now finished
    	  	Call the chooseMinMaxMove(Node root)to choose the best available move.
    	  	Move the player.
    	  	Update path variable.
    	  	Return the best move.*/
    	  		Integer[] currentPath =new Integer[4];
    	  		Supply[] supplies=board.getSupplies();
        		for(int j=0 ; j < supplies.length ; j++ ) {
        			
        			if(currentPos == supplies[j].getsupplyTileId()) { 
        				setScore(getScore()+1);	//increasing the score by 1.									
    					//move[3]=supplies[i].getsupplyId();	//[3]= SUPPLY ID							
    					System.out.println("YOU GOT A SUPPLY, GOOD JOB: "+getScore());
    					currentPath[1]=1;
        				supplies[j].setX(-1);
        				supplies[j].setY(-1);
        				supplies[j].setsupplyTileId(-1);		//changing the variables of the supply so as to be deleted from the map.
        				
        				break;
        				}
        			else {
    					 //[3]= SUPPLY ID
    					currentPath[1]=0;
    				 }
        		}
        			
        			
    	  		int indexOfBestMove=0;
    	  		//creating a node that will be the root of the tree
    	  		Node root=new Node();
    	  		//update the variables of the rootNode so as to make it a root.
    	  		root.setNodeBoard(getBoard());// the board is the board of the player
    	  		int[] rootNodeMove= new int[3];
    	  		rootNodeMove[0]=getX();
    	  		rootNodeMove[1]=getY();
    	  		rootNodeMove[2]=0;//default value of dice only for nodes that are roots.
    	  		root.setNodeMove(rootNodeMove);
    	  		root=createMySubtree(currentPos,opponentCurrentPos,root,root.getNodeDepth()+1);//calling to create the tree.
    	  		//call the chooseMinMaxMove
    	  		indexOfBestMove=chooseMinMaxMove(root);

        	
        		
    	  		//Move the player.
    	  		Node bestNode=new Node();//the level 1 that MinMax Algorithm proposed.
    	  		bestNode=root.getChildren().get(indexOfBestMove);
    	  		currentPath=move(bestNode.getNodeMove()[2],currentPath);//here we make the move
    	  		//Update Path
    	  		//path[0]=dice
    	  		//path[1]= 1 if Theseus took a supply.
    	  		//path[2]=supply distance
    	  		//path[3]=minotaur distance
    	  		//tileId of the New Tile in which Theseus is in.
    	  		int bestTileId=getTile(bestNode.getNodeMove()[0],bestNode.getNodeMove()[1]).getTileId();
    	  		currentPath[0]=bestNode.getNodeMove()[2];
    	  		currentPath[2]=0;
    	  		
    	  		currentPath[2]=supplyDistFinder(currentPath[0],currentPos,opponentCurrentPos); //we see at direction 1
    	  		/*for(int i=3;i<8;i++) {											//we compare the values and search for the closest supply
    	  			if(supplyDistFinder(i,currentPos,opponentCurrentPos)<currentPath[2] && supplyDistFinder(i,currentPos,opponentCurrentPos)!=0) {//if at direction i the supply is closest to us, we choose this distance
    	  				currentPath[2]=supplyDistFinder(i,currentPos,opponentCurrentPos);
    	  			}
    	  			
    	  		}*/
    	  		currentPath[3]=0;
    	  		for(int i=1;i<8;i++) {							//the minotaurus is one, and we search for him in every direction of our tile
    	  			currentPath[3]+=minoDistFinder(i,currentPos,opponentCurrentPos);
    	  			
    	  		}
    	  		
    	  		
    	  		path.add(currentPath);
    	  		
    	  		StatisticsCounter(currentPath[0]);
    	  		
    	  		return bestTileId;
    	  		
    	  		//return best move
    	  	}

  	public Node createMySubtree(int currentPos, int opponentCurrentPos,Node root,int depth) {
  		
  	/*Find the number of available movements.
  	For each available movement (dice):
  	Create a clone of the root node�s board and simulate making the movement.
  	Create a new node as child of the parent node using the new board state.
  	child.nodeEvaluation <- evaluate(dice, ..)
  	Add the node (newNode) as child of the parent node.
  	Complete the tree branches by calling createOpponentSubtree(newNode, depth+1, ..)
  	*/
  		
  		Tile localTile=new Tile();// in this tile we save the original position of the player.
  		ArrayList<Integer> h=new ArrayList<Integer>(); //ArrayList to save the Possible moves of the original position.
  		localTile=getTile(root.getNodeMove()[0],root.getNodeMove()[1]);//we take the tile according to the root.
  		h=PossibleMoves(localTile);//we find the possible moves of the player given his initial tile.
  		int counter=0;// this counter is used to count the children created in level 1 so as to be equal to the number of possible moves.
  		
  		
  		
  		
  		while(counter<h.size()) {
  			Node childNode=new Node();// a node created in every iteration that is one of the children of the root in level 1.
  			double childEvaluation=0;
  			int [] virtualMove=new int[3];
  			// we create a new MinMaxPlayer that will help us keep the game unchanged during the algorithm.
  			
  			MinMaxPlayer virtualPlayer=new MinMaxPlayer(playerId,name,board,score,x,y,opponentCurrentPos);
  			//we set every nodes's parent to be the root.
  			childNode.setParent(root);
  			//here we practically set the depth to be 2-1=1;
  			childNode.setNodeDepth(depth);
  			
  			switch(h.get(counter)) {
  			case 1://up
  				
  				virtualPlayer=theoreticalMove(1,virtualPlayer);//make the move theoretically.(includes deleting the supplies taken).
  				virtualMove[0]=virtualPlayer.getX();// setting  the nodeMove[]
  				virtualMove[1]=virtualPlayer.getY();
  			    virtualMove[2]=1;
  				childNode.setNodeMove(virtualMove);
  				childNode.setNodeBoard(virtualPlayer.getBoard());
  				//adding the node as a child.
  				root.addChildren(childNode);
  				
  				currentPos=getTile(virtualMove[0],virtualMove[1]).getTileId();
  				
  				
  				childEvaluation=evaluateGeneralPos(currentPos,opponentCurrentPos); //evaluate the movement of Theseus going up.
  				childNode.setNodeEvaluation(childEvaluation);//setting the evaluation variable of the node.
  				childNode.setTheseusPos(currentPos);
  				childNode.setMinoPos(opponentCurrentPos);
  				
  				
  				
  				break;
  			case 3: //right
  				
  				virtualPlayer=theoreticalMove(3,virtualPlayer);
  				virtualMove[0]=virtualPlayer.getX();
  				virtualMove[1]=virtualPlayer.getY();
  			    virtualMove[2]=3;
  				childNode.setNodeMove(virtualMove);
  				childNode.setNodeBoard(virtualPlayer.getBoard());
  				root.addChildren(childNode);
  				currentPos=getTile(virtualMove[0],virtualMove[1]).getTileId();
  				childEvaluation=evaluateGeneralPos(currentPos,opponentCurrentPos); //evaluate the movement of Theseus going up.
  				childNode.setNodeEvaluation(childEvaluation);//setting the evaluation variable of the node.
  				//NEW ADD
  				childNode.setTheseusPos(currentPos);
  				childNode.setMinoPos(opponentCurrentPos);
  				
  				
  				
  				break;
  			case 5://down
  				
  				virtualPlayer=theoreticalMove(5,virtualPlayer);
  				virtualMove[0]=virtualPlayer.getX();
  				virtualMove[1]=virtualPlayer.getY();
  			    virtualMove[2]=5;
  				childNode.setNodeMove(virtualMove);
  				childNode.setNodeBoard(virtualPlayer.getBoard());
  				root.addChildren(childNode);
  				currentPos=getTile(virtualMove[0],virtualMove[1]).getTileId();
  				childEvaluation=evaluateGeneralPos(currentPos,opponentCurrentPos); //evaluate the movement of Theseus going up.
  				childNode.setNodeEvaluation(childEvaluation);//setting the evaluation variable of the node.
  				//NEW ADD
  				childNode.setTheseusPos(currentPos);
  				childNode.setMinoPos(opponentCurrentPos);
  				
  				
  				
  				break;
  			case 7://left
  				
  				virtualPlayer=theoreticalMove(7,virtualPlayer);
  				virtualMove[0]=virtualPlayer.getX();
  				virtualMove[1]=virtualPlayer.getY();
  			    virtualMove[2]=7;
  				childNode.setNodeMove(virtualMove);
  				childNode.setNodeBoard(virtualPlayer.getBoard());
  				root.addChildren(childNode);
  				currentPos=getTile(virtualMove[0],virtualMove[1]).getTileId();
  				childEvaluation=evaluateGeneralPos(currentPos,opponentCurrentPos); //evaluate the movement of Theseus going up.
  				childNode.setNodeEvaluation(childEvaluation);//setting the evaluation variable of the node.
  				
  			
  				childNode.setTheseusPos(currentPos);
  				childNode.setMinoPos(opponentCurrentPos);
  				
  				
  				
  				break;
  			
  			}
  			counter++;	
  	
  		}
	for(Node child:root.getChildren()) {											//here we are creating the opponent sub tree 
																					//for each child we take the posiible moves of minotaurus
		 createOpponentSubtree(child.getTheseusPos(),child.getMinoPos(),child,depth+1);
		 
  			
  		}
  		
  		
  		return root;
  	}
  	/*
  	 * This method creates the opponent sub tree.In this sub tree the theseus has the same position as the parent( theseus sub tree )
  	 * For each child of the root we create the children depended on minotaurus moves.
  	 * Then we save the positions at the TheseusPos and MinoPos and we evaluate the node with the evaluation method.
  	 * At the end we add the node at the tree
  	 */
	public Node createOpponentSubtree(int currentPos, int opponentCurrentPos,Node parent,int depth) {
		ArrayList<Integer> minoPossibleMoves=PossibleMoves(board.getTiles()[opponentCurrentPos]);
		
		for(int i:minoPossibleMoves) {  // create node for each child(mino moves)
			ArrayList<Node> children=new ArrayList<Node>();
			int[] nodeMove=new int[3];
			nodeMove[0]=-1;						//Theseus did not moved so we set nodeMove=-1
												
			nodeMove[1]=-1;
			nodeMove[2]=i;						//set nodeMove[2] = Minotaurus direction move
			
			Node grandChild=new Node(parent,children,depth,nodeMove,parent.getNodeBoard(),0);		//create grand child
			grandChild.setTheseusPos(currentPos);													//setting the players positions
			grandChild.setMinoPos(diceToTile(i,opponentCurrentPos,0));
			grandChild.setNodeEvaluation(evaluateGeneralPos(currentPos,diceToTile(i,opponentCurrentPos,0)));	//evaluate the Node
			parent.addChildren(grandChild);															//add the node to the tree
				
		}
		return parent;												//return the root
		
	}
 
 
 // in this function we make the move by changing the board of the virtual player, so as not to change the varibles of the original player.
 	public MinMaxPlayer theoreticalMove(int dice,MinMaxPlayer virtualPlayer){
 		Tile playerTile = getTile(virtualPlayer.getX(),virtualPlayer.getY());//we find the tile that the player is in currently.
 		int[] move = new int[4];						//[0]=tileId
 		//[1]=X
 		//[2]=Y
 		switch(dice){	//here we move the player to the next tile(using its tileId)by changing the x and y coordinates.
 			case 1:
 				virtualPlayer.setY(virtualPlayer.getY() + 1);
 				break;
 			case 3:
 				virtualPlayer.setX(virtualPlayer.getX() + 1);
 				break;												
 			case 5:
 				virtualPlayer.setY(virtualPlayer.getY() - 1);
 				break;
 			case 7:
 				virtualPlayer.setX(virtualPlayer.getX() - 1);  
 				break;
 		}
 		move[0] = getTile(virtualPlayer.getX(),virtualPlayer.getY()).getTileId();	//[0]=tileId
 		move[1] = virtualPlayer.getX(); //[1]=x
 		move[2] = virtualPlayer.getY();//[2]=y
 		Tile[] tiles = virtualPlayer.getBoard().getTiles();	
 		Supply[] supplies = virtualPlayer.getBoard().getSupplies();// we check for the supplies in the virtual player's board so as not to change the original board.
 		// if the virual player goes in a tile with a supply in it we must make the supply disappear so as not to have a false evaluation.
 		for(int i=0 ; i < supplies.length ; i++ ) {
 			if(tiles[playerTile.getTileId()].getTileId() == supplies[i].getsupplyTileId()) { 	
 				virtualPlayer.setScore(getScore()+1);	//increasing the score by 1.									
 				move[3]=supplies[i].getsupplyId();	//[3]= SUPPLY ID								
 				supplies[i].setX(-1);
 				supplies[i].setY(-1);
 				supplies[i].setsupplyTileId(-1);//changing the variables of the supply so as to be deleted from the map.
 				
 				}
 			else move[3]=0; //[3]= SUPPLY ID
 			}
 		
 		return virtualPlayer;
 	}
 	/*
 	 *This method helps us to update the path for each move we choose.
 	 *Takes us argument the direction that will follow theseus and updates the path 
 	 * @param dice
 	 * @param currentPath
 	 * @return
 	 */
 	public Integer[] move(int dice,Integer[] currentPath){
		Tile playerTile = getTile(getX(),getY());//we find the tile that the player is in currently.
		int[] move = new int[4];			//[0]=tileId
											//[1]=X
											//[2]=Y
											//[3]= SUPPLY ID
		switch( dice ){	//here we move the player to the next tile(using its tileId)by changing the x and y coordinates.
			case 1:
				setY(getY() + 1);
				
				break;
			case 3:
				setX(getX() + 1);
				
				break;												
			case 5:
				setY(getY() - 1);
				
				break;
			case 7:
				setX(getX() - 1);
			
				break;
		}
		move[0] = getTile(getX(),getY()).getTileId();	//[0]=tileId
		move[1] = getX(); //[1]=x
		move[2] = getY();//[2]=y
		Tile[] tiles = board.getTiles();	
		Supply[] supplies = board.getSupplies();
		for(int i=0 ; i < supplies.length ; i++ ) {
			if(tiles[playerTile.getTileId()].getTileId() == supplies[i].getsupplyTileId()) { 	
				setScore(getScore()+1);	//increasing the score by 1.									
				move[3]=supplies[i].getsupplyId();	//[3]= SUPPLY ID							
				System.out.println("YOU GOT A SUPPLY, GOOD JOB");	
				supplies[i].setX(-1);
				supplies[i].setY(-1);
				supplies[i].setsupplyTileId(-100);//changing the variables of the supply so as to be deleted from the map.
				
				}
			else move[3]=0; //[3]= SUPPLY ID
		}
			
		if(PossibleMoves(playerTile) == null) {//in case there is no possible move											
			System.out.println("ERROR YOU CANNOT MOVE"); 
			}
		return currentPath;
		
	}
    	  	
	
	/*
	 * this method returns an int that has the value of the dice that the player must choose, in order to play with MINMAX logic
	 * the childrenBest Arraylist<Integer> contains the indexes of children ArrayLists( the one inside the other ) that shows us the MIN MAX path of the tree
	 * we use this ArrayList(Children Best) in order to know which dice must choose the player in order to got the MIN MAX MOVE
	 * After the use of this method we must delete all the childrenBest items in order to use it on the next move 
	 */
	int chooseMinMaxMove(Node root) {
		int minMaxMove=FindMinMaxIndex(root,2); //we call the method that does all the job and finds the index

		return minMaxMove;
		
	}
	/*
	 * this method is the MinMax algorithm, we start from the bottom of the tree where we have the sum of the node evaluations of the path that the player must
	 * follow in order to go at this CHILD node
	 * Is a recursive method and it will be called DEPTH times
	 * if the depth reaches the minimum value of 0 we return the value of the path, we do this for each child
	 * For the first FINAL child of the FOR loop, we compare his value of the path with the (MAX +100, or MIN -100) and we store the minimum or the maximum
	 * so now we have stored the max or min value in the variable VALUE and we go on the next child and we compare the value of the child with the VALUE
	 * If the player is maximizing we search  the MAX value
	 * If the player is minimizing( maximizing=false ) we search the MIN value
	 * For every MIN OR MAX value, we store at an ArrayList( called childrenBest ) the index of each (MIN-MAX) child( from children ArrayList ) in order to know the path
	 * and choose the correct dice.
	 * "The Last item of the childrenBest ArrayList( indexes )"=HELPER it shows us the index of root's ArrayList "children" that we must choose in order to got the MINMAX 
	 * in other words this is the data that tells us that we must choose DICE=root.getChildren().get(HELPER).getNodeMove()[2]
	 */
	double MinMax(Node node,int depth,boolean maximizingPlayer) {
		double value;
		
		if(depth == 0 || node.getChildren().isEmpty()) { //this is an if statement if we got at depth=0 or the node we searching hasn't children but the depth of minMax is not 0 
			if(node.getChildren().isEmpty() && depth!=0) {
				return pathEvaluation(node,0);
			}
			return pathEvaluation(node,1);
		}
		
		if(maximizingPlayer) {
			value=-100;
			
			
			for(Node child : node.getChildren()) {
				value=Max(value,MinMax(child,depth-1,false));
				
				
			}//finally the VALUE has the Max value of the children
			//and then we search which child had the VALUE and we store its index in order to know the path to got there
			
			return value;
		}
		else {
			value=+100;
			
			for(Node child : node.getChildren()) {
				value=Min(value,MinMax(child,depth-1,true));	
			}
			
			return value;
			
		}
	}
	/*
	 *This method is called by the chooseMinMax method, it finds the index for the Min-Max move  
	 *if all the evaluations are 0 we play randomly
	 *
	 */
	int FindMinMaxIndex(Node root,int depth) {
		int index=0;
		int zeroCounter=0;
		int grandChildrenNum=0;
		for(Node child:root.getChildren()) {
			for(Node finalChild:child.getChildren()) {
				if(MinMax(root,2,true)==pathEvaluation(finalChild,1)) {
					index=root.getChildren().indexOf(child);
				}
			}
		}
		for(Node child:root.getChildren()) {
			grandChildrenNum+=child.getChildren().size();
			for(Node finalChild:child.getChildren()) {
				if(pathEvaluation(finalChild,1)!=0) {
					
					 return index;
				}
				else {
					zeroCounter++;
					
				}
			}
		}
		
		if(zeroCounter==grandChildrenNum) {					//random play
			ArrayList<Integer> shuffler=new ArrayList<Integer>();	//take the possible moves in ArrayList
			for(int i=0;i<root.getChildren().size();i++) {
				shuffler.add(i);
			}
				Collections.shuffle(shuffler); 					//shuffle the ArrayList
			
			index=shuffler.get(0);								//get the first element
			return index;
		}
		
		return index;
		
	}
	/*
	 * method that helps us in minMax algorithm
	 * returns the biggest of the two arguments
	 */
	double Max(double value,double minmax) {
		//minmax()=MinMax(child,depth-1,false)
		if(value<minmax) { 
			return minmax;
			
		}
		else return value;
		
	}
	/*
	 * method that helps us in minMax algorithm
	 * returns the minimum of the two arguments
	 */
	double Min(double value, double minmax) {
		if(value>minmax) {
			return minmax;
		}
		else return value;
	}
	/*
	 * this is a recursive that will add the NodeEvaluations in order to find the MinMax path
	 * we will start from the child and we will go up to the root
	 * it's an alternative of subtraction of the nodeEvaluations
	 * this method gives us the values from the tree
	 * and with the minMax algorithm we will find the wanted value;
	 * DOWN TO UP
	 * recursive=depth-1 because we do not want the nodeEvaluation of the root
	 */
	double pathEvaluation(Node childToParent,int recursive) {
		double eval=childToParent.getNodeEvaluation();			//the node evaluation of the child
		if(recursive==0) return eval;
		else {
			eval+=pathEvaluation(childToParent.getParent(),recursive-1);
		}
		return eval;
	}
	/*
	 * This method helps us to evaluate the future-position of the player, we add all the known evaluations(one for each future dice) about this position. 
	 * We do this in order to have values for MinMax algorithm.
	 * This method helps us to understand if the move that will make our player will have any profit
	 * the previous evaluate gives info about one direction DICE but now we don't care about only one direction
	 * So we use this method to evaluate the possible game states
	 */
	public double evaluateGeneralPos(int currentPos,int opponentPos) {
		double generalEvaluation=0;
		
		ArrayList<Integer> theseusEye=PossibleMoves(board.getTiles()[currentPos]);
		for(int i : theseusEye) {
			generalEvaluation+=evaluate(i,currentPos,opponentPos);				//we evaluate the position that the player will be, by adding all the evaluations about all the directions
			
			Supply[] supplies=board.getSupplies();								//Search for supplies, if the theseus move will be at a tile with a supply we add 1 in the evaluation
			for(int j=0 ; j < supplies.length ; j++ ) {
				
				if(currentPos == supplies[j].getsupplyTileId()) { 
														
											
					
					
				    generalEvaluation+=1;
					break;
					}
				
				
				}
			
		}
		return generalEvaluation;
	}
    /*
     * this method evaluates the dice of the player,
     * it uses the other methods to find the distances
     * if it does not  have an information about the distances it returns 0
     */
	public double evaluate(int dice , int currentPos,int opponentPos) {
	
		double minotaurDist=minoDistFinder(dice,currentPos,opponentPos);
		//System.out.println("THIS is the mino dist "+minotaurDist+ " in  TILE ID"+currentPos+" OPPONENT POS"+opponentPos);
		
    	double supplyDist=supplyDistFinder(dice,currentPos,opponentPos);
    	double f=0;
    	//if(currentPos==opponentPos) return -20;
    	if(minotaurDist==supplyDist && minotaurDist!=0) {   //if a supply is at the same Tile with the Minotaurus we evaluate as -1, because we do not want to take it
    		f=-1;
    	}

		
		
        if(minotaurDist==0&&supplyDist==0) {				//if we do not have any clue about the supplies or the minotaurus, and the player will  not be at the same tile with Minotaurus we return 0
        	if(currentPos==opponentPos) return -5;			//if the player gonna be at the same tile with the Minotaurus we evaluate it as -5, which evaluation is called for each direction (3 possible->-15)
            return 0;
        }
        else if(minotaurDist==0) {
            f+=(4-supplyDist)*0.1;							//evaluation when the minotaurus is not near theseus and not at the same position
            if(currentPos==opponentPos) f=-5;				//same as previous
            return f;
        }
        
        else{
        f+=(4-supplyDist)*0.1-(2/(minotaurDist+1));		//the evaluation when we have data about minotaurus and theseus
        }

        return f;
        /* ��� �������� 3: 0.1 /0.225
         *                 2: 0.2/0.3
         *                 1: 0.3/0.45
         */
        }
	
	
	  public int minoDistFinder(int dice, int TileId,int opponentPos) {
	        //ArrayList<DataContainer> DataCollection=dataCollectDice(dice,TileId,opponentPos);
	        int minoDist=0;
	        int checkTileId;
	        Tile[] tiles=board.getTiles();
	        for(int i=0;i<3;i++) {
	        	checkTileId=diceToTile(dice,TileId,i);
	        	if(getHelperWall(tiles[checkTileId],dice)) {
	        		return 0;
	        		
	        	}
	        	else if(checkTileId==opponentPos) {
	        		return i+1;
	        	}
	        }
	        
	 
	        return minoDist;
	    }
	/*
	 * this method is similar with the minoDistFinder,it is the same ArrayList(with DataCollectDice method) but at this time we search for supplies in the DataContainers
	 * we check again if there is wall, and then search the supply variable of the DataContainers
	 * if there is a supply we return the distance that has the player from the supply
	 */
public int supplyDistFinder(int dice,int TileId,int opponentPos) {
		
		Tile[] tiles=board.getTiles();
		
		int checkTileId;
		for(int i=0;i<3;i++) {
			checkTileId=diceToTile(dice,TileId,i);
			if(getHelperWall(tiles[checkTileId],dice)) {
				return 0;
			}
			else if(SupplyHelper(checkTileId)) {
				return i+1;
				
			}
			
		}
		return 0;
    }
    /*
     * this method helps us to search the wanted wall, returns the opposite direction of the dice
     *  +   +   +---+   +---+
		|                   |
		+   +   +   +   +   +
		|         T         |
		+   +   +---+   +   +   
		|       | M         |
		+   +   +   +   +   +   
     *  in the above case if the player wants to search  the dice=5 he must see the wall of the next Tile that is in the direction 1
     *  so we use this function to reverse the direction 
     */
    public int oppositeDirection(int dice) {
        switch(dice) {
        case 1:
            return 5;
        case 3:
            return 7;
        case 5:
            return 1;
        case 7:
            return 3;
        default: return 0;
        }
    }
    
    /*
     * this method is a recursive method, takes as arguments the dice, the TileId of the player and the number of walls we want to search-1( this is the recursive counter)
     * for recursiveCounyer=0 it will return the Tile Id of the first Tile in the direction we want to search
     * for recursiveCounyer=1 it will return the Tile Id of the second Tile in the direction we want to search,and  so go on
     *  it calls the method nextTileAcceptableTileId, in order to check if it is acceptable the Tile Id that will return 
     */
    public int diceToTile(int dice, int TileId, int recursiveCounter) {
    	int newTileId=TileId;															//this is the value if the TileId is not acceptable
    	if(nextTileAcceptableTileId(dice,TileId)==true) {
	    	switch(dice) {
		    	case 1:
		    		newTileId=TileId+board.getN();									//above tile
		    		break;
		    	case 3:
		    		newTileId=TileId+1;												//right tile
		    		break;
		    	case 5:
		    		newTileId=TileId-board.getN();									//down tile
		    		break;
		    	case 7:
		    		newTileId=TileId-1;												//left tile
		    		break;
	    	}
	    	if(recursiveCounter>0) {
	    		return diceToTile(dice,newTileId,recursiveCounter-1);				//here it calls itself to get the next tile in the DICE direction
	    	}
	    	else return newTileId;
    	}
    	else return newTileId;
    }
    
    /*
     * this method checks if is acceptable the Tile Id of the tile we want to search
     * its not acceptable to go to next Tile if the current tile is at the first or last row,or at the first or last column of the board
     */
    public Boolean nextTileAcceptableTileId(int dice,int TileId) {
    	Boolean nextTileExists=true;
    	switch(dice) {
    	case 1:													// check is at the top
    		if(TileId+board.getN()>=board.getN()*board.getN()) {   //we check if the above tile , exists, if it has Id bigger than N*N it is out of bounds
    			nextTileExists=false;
    		}
    		break;
    	case 3:
    		if(TileId%board.getN()==(board.getN()-1)) {					//checks if it is in the last right column
    			nextTileExists=false;
    		}
    		break;
    	case 5:
    		if(TileId-board.getN()<0) {							//checks if it is at the at the first row
    			nextTileExists=false;
    		}
    		break;
    	case 7:
    		if(TileId%board.getN()==0) {						//checks if its at the first left column
    			nextTileExists=false;
    		}
    		break;
    	}
    	return nextTileExists;
    	
    }
    /* In the functions statistics which is called only in the end of the game we print out information about each and every round, but some information about the total movement of our Heristic Player
	 * as well. To do so, we use the ArrayList path where every round's information is stored and 4 static variables just to avoid using more loops in this simple function.
	 */
	public void statistics(int finalRound) {
		System.out.println();
		int localScore=0;
		for(int counter=0; counter< finalRound+1 ;counter++) {
		System.out.println("In the "+ (counter) +" round of the game Theseus:");
		if(path.get(counter)[1]==1) {
			localScore++;
			System.out.println("1) had gathered "+ localScore + " supplies(until that time).");
		}
		else {
		System.out.println("1) had gathered "+ (localScore) + " supplies.");
		}
		
		if(pickingSupply==1) {
			System.out.println("2) the theseus was trying to pick up the supply and was "+ path.get(counter)[2] +" blocks away from the closest supply(reminder:default value is 0)");
			pickingSupply=0;
		}
		else {
			System.out.println("2) was "+ path.get(counter)[2] +" blocks away from the closest supply(reminder:default value is 0)");
		}
		if(path.get(counter)[2]==1) {
			pickingSupply=1;
		}
		
		System.out.println("3) was "+ path.get(counter)[3] +" blocks away from Minotaur(reminder:default value is 0)");
		System.out.println("-------------------------------------------------");
		System.out.println();
		}
			System.out.println("Total times Theseus went front: " + totalTimesFront);
			System.out.println("Total times Theseus went back: " + totalTimesBack);
			System.out.println("Total times Theseus went right: " + totalTimesRight);
			System.out.println("Total times Theseus went left: " + totalTimesLeft);
		}
	/*
	 * this method is called in order to update the the static variables that help us in statistics
	 */
	public void StatisticsCounter(int dice) {
		
		
		switch(dice) {
		case 1:
			totalTimesFront+=1;
			
			break;
		case 3:
			totalTimesRight++;
			
			break;
		case 5:
			totalTimesBack++;
			

			break;
		case 7:
			totalTimesLeft++;
			

			break;
		}
	}
		/*
		 * is called by the supplyDistFinder and checks if at the currentPos (this is the future tile) tile is any supply
		 */
		public boolean SupplyHelper(int currentPos) {
			Supply[] supplies=board.getSupplies();
			for(int j=0 ; j < supplies.length ; j++ ) {
				
				if(currentPos == supplies[j].getsupplyTileId()) { 						
					return true;
					
					}
				
			}
			return false;
		}
		/*
		 * Helps us to find the walls, in oreder to know if theseus can see the supply
		 * we take the opposite direction wall
		 */
		public boolean getHelperWall(Tile tile,int dice) {
			boolean helper=false;
			switch(dice) {
			case 1:
				if(tile.getDown()) helper=true;
				break;
			case 3:
				if(tile.getLeft()) helper=true;
				break;
			case 5:
				if(tile.getUp()) helper=true;
				break;
			case 7:
				if(tile.getRight()) helper=true;
				break;
			}
			return helper;
		}
	
}

	
	
	
	
	
	