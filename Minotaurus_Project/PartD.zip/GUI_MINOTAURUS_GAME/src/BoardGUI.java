import javax.swing.*;
import java.awt.*;
import java.util.*;

/*
 * This class is the gui of the board class, and has methods that help in creating the gui of the maze
 */
public class  BoardGUI extends JPanel{
	private int N;//dimensions
	Board gameBoard;
	TileGUI[] TilesGUI;
	JPanel boardPanel;
	int TheseusPos;
	int MinoPos;
	
	public void BoardGUI() {
		N=0;
		gameBoard=new Board();
		TilesGUI=new TileGUI[0];
		boardPanel=new JPanel();
		TheseusPos=0;
		MinoPos=0;
	}
	public BoardGUI(Board gameBoard,int TheseusPos,int MinoPos){
		this.TheseusPos=TheseusPos;
		this.MinoPos=MinoPos;
		this.gameBoard=gameBoard;
		N=gameBoard.getN();
		TilesGUI=new TileGUI[N*N];
		
		boardPanel=new JPanel(new GridLayout(N,N));
		//boardPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 10));
		createTilesGUI();
		createBoardGUI();
	}
	
	//setters
	public void setN(int N) {
		this.N=N;
	}
	public void setBoard(Board gameBoard) {
		this.gameBoard=gameBoard;
	}
	public void setTilesGUI(TileGUI[] TilesGUI) {
		this.TilesGUI=TilesGUI;
	}
	public void setboardPanel(JPanel boardPanel) {
		this.boardPanel=boardPanel;
	}
	public void setTheseusPos(int TheseusPos) {
		this.TheseusPos=TheseusPos;
	}
	public void setMinoPos(int MinoPos) {
		this.MinoPos=MinoPos;
	}
	
	//getters
	public int getN() {
		return N;
	}
	public Board getgameBoard() {
		return gameBoard;
	}
	public TileGUI[] getTilesGUI() {
		return TilesGUI;
	}
	public JPanel getboardPanel() {
		return boardPanel;
	}
	public int getTheseusPos() {
		return TheseusPos;
	}
	public int getMinoPos() {
		return MinoPos;
	}
	
	
	//this method creates the TileGUI array
	public void createTilesGUI() {
		for(int i=0;i<N*N;i++) {
			TilesGUI[i]=new TileGUI(gameBoard.getTiles()[i]);
		}
	}
	//we add the tiles on the board
	public void createBoardGUI() {
		int TilesIndex=0;
		for(int j=N*N-N;j>=0;j-=N) {
			for(int i=j;i<=j+N-1;i++) {
				//TilesGUIReverser();
				boardPanel.add(TilesGUI[i].getmainPanel());
				
				
			}
		}
		addSupplies();//adding supplies
		addCharacters();//adding characters
		
		
		
	}
	public void TilesGUIReverser() {
		TileGUI[] reversed=new TileGUI[N*N];
		int k=0;
		for(int i=N*N-N-1;i>=0;i-=N) {
			for(int j=N-1;j>=0;j--) {
				reversed[k]=TilesGUI[i+j].getmainPanel();
				k++;
			}
		}
		this.setTilesGUI(reversed);
	}
	//adding characters 
	public void addCharacters() {
		IconCharacter theseus=new IconCharacter(this); //JLabel
		IconCharacter mino=new IconCharacter(this);
		
		theseus.addCharacter("THESEUS");
		mino.addCharacter("MINO");
		
		if(TheseusPos>=0 && MinoPos>=0) {
			this.TilesGUI[this.TheseusPos].getmainPanel().add(BorderLayout.CENTER,theseus);
			this.TilesGUI[this.MinoPos].getmainPanel().add(BorderLayout.CENTER,mino);
	
		}
		else System.out.println("ERROR OUT OF BOARD BOUNDS");
	}
	//adding the supplies
	public void addSupplies() {
		int helper=0;
		for(int i=0;i<gameBoard.getS();i++) {
			
			if(gameBoard.getSupplies()[i].getsupplyTileId()>=0) {
				SupplyGUI supply=new SupplyGUI(this);
				supply.addSupply();
				this.TilesGUI[gameBoard.getSupplies()[i].getsupplyTileId()].getmainPanel().add(BorderLayout.CENTER,supply);
			}
			
		}
	}
	//this method is not used
	public void resetBoard(Board board,int theseus, int Mino) {
		//BoardGUI(board,theseus,Mino);
		this.TheseusPos=theseus;
		this.MinoPos=Mino;
		this.gameBoard=board;
		createTilesGUI();
		createBoardGUI();
	}
	
	
	
	
	
	
	
	
	
	
	
}
