
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.*;

public class TileGUI extends JPanel {
	TileGUI mainPanel;
	private int TileGuiID;
	private int xGrid;
	private int yGrid;
	JPanel upWallPanel;
	JPanel rightWallPanel;
	JPanel downWallPanel;
	JPanel leftWallPanel;
	HashMap<Integer,JPanel> wallsGui;
	
	public TileGUI() {
		super(new BorderLayout());
		
		TileGuiID=0;
		xGrid=0;
		yGrid=0;
		
		upWallPanel=new JPanel();			//1
		rightWallPanel=new JPanel();		//3
		downWallPanel=new JPanel();			//5
		leftWallPanel=new JPanel();			//7
		
		
		wallsGui=new HashMap<Integer,JPanel>(); //we will store the panel walls for easy access
		wallsGui.put(1, upWallPanel);
		wallsGui.put(3, rightWallPanel);
		wallsGui.put(5, downWallPanel);
		wallsGui.put(7, leftWallPanel);
		
		WallBuilder(null);//we build the walls(are white)
		
	}
	public TileGUI(Tile baseTile) {
		//super(new BorderLayout());
		mainPanel=WallPutter(baseTile); //with this method is like we call the empty constructor
		mainPanel.setTileGuiID(baseTile.getTileId());
		mainPanel.setxGrid(baseTile.getX());
		mainPanel.setyGrid(baseTile.getY());
		
		
		
		mainPanel.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		WallBuilder(baseTile); //we build the walls of the given tile
		
		
		
	}
	//setters
	public void setmainPanel(TileGUI mainPanel) {
		this.mainPanel=mainPanel;
	}
	public void setTileGuiID(int TileGuiId) {
		this.TileGuiID=TileGuiId;
		
	}
	public void setxGrid(int xGrid) {
		this.xGrid=xGrid;
		
	}
	public void setyGrid(int yGrid) {
		this.yGrid=yGrid;
		
	}
	public void setupWallPanel(JPanel upWallPanel) {
		this.upWallPanel=upWallPanel;
	}
	public void setrightWallPanel(JPanel rightWallPanel) {
		this.rightWallPanel=rightWallPanel;
	}
	public void setdownWallPanel(JPanel downWallPanel) {
		this.downWallPanel=downWallPanel;
	}
	public void setleftWallPanel(JPanel leftWallPanel) {
		this.leftWallPanel=leftWallPanel;	
	}
	
	//getters
	public TileGUI getmainPanel() {
		return mainPanel;
	}
	public int getTileGuiID() {
		return TileGuiID;
	}
	public int getxGrid() {
		return xGrid;
	}
	public int getyGrid() {
		return yGrid;
	}
	public JPanel getupWallPanel() {
		return upWallPanel;
	}
	public JPanel getrightWallPanel() {
		return rightWallPanel;
	}
	public JPanel getdownWallPanel() {
		return downWallPanel;
	}
	public JPanel getleftWallPanel() {
		return leftWallPanel;
	}
	public HashMap<Integer,JPanel> getwallsGui(){
		return wallsGui;
	}
	
	/*
	 * This method take as argument a tile, checks the walls of the tile and then paints black the corresponding GUI WALL
	 */
	public void WallBuilder(Tile baseTile) {
		if(baseTile!=null ) {
			
			if(baseTile.getUp()) {
				//mainPanel.getwallsGui().get(1).add(WallThinner(1));
				mainPanel.getwallsGui().get(1).setBackground(Color.BLACK);
			}
			if(baseTile.getRight()) {
				//mainPanel.getwallsGui().get(3).add(WallThinner(3));
				if(IsTileExternal(baseTile)) {
				mainPanel.getwallsGui().get(3).setBackground(Color.BLACK);
				}
			}
			if(baseTile.getDown()) {
				//mainPanel.getwallsGui().get(5).add(WallThinner(5));
				if(IsTileExternal(baseTile)) {
					mainPanel.getwallsGui().get(5).setBackground(Color.BLACK);
					//JLabel icon=new JLabel(new ImageIcon(this.getClass().getResource("/wall2.3.jpg")));
					//mainPanel.getwallsGui().get(5).add(icon);
				}
			}
			if(baseTile.getLeft()) {
				//mainPanel.getwallsGui().get(7).add(WallThinner(7));
				mainPanel.getwallsGui().get(7).setBackground(Color.BLACK);
			}
		}
	}
	/*
	 * this method puts thw walls in the correct direction
	 */
	public TileGUI WallPutter(Tile baseTile) {
		TileGUI mainTilePanel=new TileGUI();     //calls the empty constructor
		if(baseTile.getUp()) {
			mainTilePanel.add(BorderLayout.NORTH,mainTilePanel.getwallsGui().get(1));
		}
		if(baseTile.getRight()) {
			if(IsTileExternal(baseTile) && baseTile.getX()==14) {
			mainTilePanel.add(BorderLayout.EAST,mainTilePanel.getwallsGui().get(3));
			}
		}
			
		if(baseTile.getDown()) {
			if(IsTileExternal(baseTile) && baseTile.getY()==0) {
			mainTilePanel.add(BorderLayout.SOUTH,mainTilePanel.getwallsGui().get(5));
			}
		}
		if(baseTile.getLeft()) {
	
			
			mainTilePanel.add(BorderLayout.WEST,mainTilePanel.getwallsGui().get(7));
		}
		return mainTilePanel;
	}
	
	public boolean IsTileExternal(Tile baseTile) {
		boolean isExternal=false;
		if(baseTile.getX()==0 || baseTile.getY()==15-1 || baseTile.getX()==14 || baseTile.getY()==0) {
			isExternal=true;
		}
		return isExternal;
	}
	public void addSword(){
		 ImageIcon sword;
			JLabel label;
		 sword=new ImageIcon(this.getClass().getResource("/SWORD4.png"));
		
		
		label=new JLabel(sword);
	
		mainPanel.add(label);
		
	    
	   
	    }

	
}
