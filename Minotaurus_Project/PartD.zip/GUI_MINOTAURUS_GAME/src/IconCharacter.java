import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.*;

/*
 * this class holds the icons of the objects(min, theseus, supply)
 */
public class IconCharacter extends JLabel{
	//ImageIcon supply;
	ImageIcon mino;
	ImageIcon theseus;
	//int supplyPos;
	int minoPos;
	int theseusPos;
	BoardGUI gameBoard;
	
	IconCharacter(BoardGUI gameBoard){
		super();
		
		this.gameBoard=gameBoard;
		
		theseus=new ImageIcon(this.getClass().getResource("/THESEUS6.jpg"));
		mino=new ImageIcon(this.getClass().getResource("/MINO2.jpg"));
		
		minoPos=gameBoard.getMinoPos();
		theseusPos=gameBoard.getTheseusPos();
		
		
		
	}
	//setters
	public void setmino(ImageIcon mino) {
		this.mino=mino;
	}
	public void settheseus(ImageIcon theseus) {
		this.theseus=theseus;
	}
	public void setminoPos(int minoPos) {
		this.minoPos=minoPos;
	}
	public void settheseusPos(int theseusPos) {
		this.theseusPos=theseusPos;
	}
	public void setgameBoard(BoardGUI gameBoard) {
		this.gameBoard=gameBoard;
	}
	
	//getters
	public ImageIcon getmino() {
		return mino;
	}
	public ImageIcon gettheseus() {
		return theseus;
	}
	public int getminoPos() {
		return minoPos;
	}
	public int gettheseusPos() {
		return theseusPos;
	}
	public BoardGUI getgameBoard() {
		return gameBoard;
	}
	//adding the icons
	public void addCharacter(String player) {
		if(player=="THESEUS" || player=="Theseus" || player=="theseus") {
			this.setIcon(theseus);
		}
		else if(player=="MINOTAURUS" || player=="MINO" || player=="Minotaurus" || player=="Mino" || player=="mino") {
			this.setIcon(mino);
		}
		else {
			System.out.println("ERROR AT CHARACTER STRING NAME");
			System.exit(ERROR);
		}
	}
}
