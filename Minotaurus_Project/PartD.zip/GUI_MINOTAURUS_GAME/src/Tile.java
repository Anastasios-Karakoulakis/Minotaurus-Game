//this class creates the tiles of the board
public class Tile {
	
	private int tileId;//The Id of the tile
	private int x;//The dimension x of the tile on the board
	private int y;//The dimension y of the tile on the board
	private boolean up;//Shows the existence of a wall on the upper side of the tile
	private boolean down;//Shows the existence of a wall on the down side of the tile
	private boolean left;//Shows the existence of a wall on the left side of the tile
	private boolean right;//Shows the existence of a wall on the right side of the tile
//this non-argument constructor set initial values in our variables
	  public Tile()
	{
		tileId=0;
		x=0;
		y=0;
		up=false;
		down=false;
		left=false;
		right=false;
		
    }  
/*this constructor takes as argument the Id of a tile and its x,y dimension variables
 and creates a tile without walls*/
	  public Tile(int tileId,int x,int y) {
	    this.tileId=tileId; 
		this.x=x; 
		this.y=y;
		up=false;
		down=false;
		left=false;
		right=false;  
	  }
//this constructor takes as argument an already existing tile and copies it.	
	  public Tile(Tile t) {
		  tileId=t.getTileId();
		  x=t.getX();
		  y=t.getY();
		  up=t.getUp();
		  down=t.getDown();
		  left=t.getLeft();
		  right=t.getRight();
	  }
//Setter of the variable tileId
	  public void setTileId(int tid) 
	  {
		  tileId = tid; 
	   }
//Setter of the variable x	  	  
	  public void setX(int x) 
	  {
		  this.x=x;
  	   }
//Setter of the variable y	  
	  public void setY(int y) 
	  {
		  this.y=y;
	   }
//Setter of the variable up	  
	  public void setUp(boolean up)
	  {
		  this.up=up ;
	   }
//Setter of the variable down	  
	  public void setDown(boolean down) 
	  {
	//	  System.out.println("setDown");
		  this.down=down;
	   }
//Setter of the variable left	  
	  public void setLeft(boolean left) 
	  {
		  this.left=left;
	   }
//Setter of the variable right	  
	  public void setRight(boolean right) 
	  {
		  this.right=right;
	   }
//Getter of the variable tileId	  
	  public int getTileId() 
	  {
		  return tileId;
	   }
//Getter of the variable x	  
	  public int getX() 
	  {
		  return x;
	   }
//Getter of the variable y	
	  public int getY() 
	  {
		  return y;
	   }
//Getter of the variable up	  
	  public boolean getUp() 
	  {
		  return up;
	   }
//Getter of the variable down	  
	  public boolean getDown() 
	  {
		  return down;
	   }
//Getter of the variable left
	  public boolean getLeft() 
      {
		  return left;
	   }
//Getter of the variable right	  
	  public boolean getRight() 
	  {
		  return right;
	   }
//This method give us when a tile has 2 walls so we cant put a 3rd.
	  public boolean twoWalls() { 
			int counter=0;
			if(up==true){
				counter++;
			}
			if(down==true) {
				counter++;
			}
			if(left==true) {
				counter++;
			}
			if(right==true) {
				counter++;
			}
			if(counter>=2) {
				return true;
			}
			else {
				return false;
			}
		}
//This method counts walls 	 
	  public int numWalls(){ 
			int counter=0;
			if(up==true){
				counter++;
			}
			if(down==true) {
				counter++;
			}
			if(left==true) {
				counter++;
			}
			if(right==true) {
				counter++;
			}
			return counter;
		}
	  
	  
}	  