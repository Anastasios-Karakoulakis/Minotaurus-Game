
import java.util.ArrayList;

public class Board {
	
	private int N; //the dimensions of the labyrinth.
	private int S;//the number of supplies in the labyrinth.
	private int W;//the maximum number of walls that will be added to the labyrinth,
	private Tile[] tiles;//an array thats stores the tiles.Their ids will have values from 0 to N^2-1.
	private Supply[] supplies; //an array that stores the supplies.Their index is based on the supplyId variable.
	int count=0; 
	//this non-argument constructor calls the second constructor with the arguments (0,0,0).So calling this constructor is actually
	// as saying Board(0,0,0) and calling the second one.
	public Board() {
	this(0,0,0);
	}
	//The only constructor actually used in this class that takes as argument the dimensions, the number of supplies and the number of
	//maximum walls and initialises the 2 arrays.The tile objects are initialized based on their id, and their x,y position.
	//The supply objects are created based on their ids but the rest of their variables are changes in createSupply();
	public Board(int N , int S, int W ) {
		this.N=N;
		this.S=S;
		this.W=W;
	    tiles=new Tile[N*N];
		for(int i=0;i<(N*N);i++) {
			int helperX=(i%N);
			int helperY=(i/N);
			tiles[i]=new Tile(i,helperX,helperY);
		}
		supplies=new Supply[S];
		for(int j=0;j<S;j++) {
			supplies[j]=new Supply(j);
		}
	}
	//This constructor that takes as an argument another board calls the 2nd constructor.
	public Board(Board b) {
		this(b.getN(),b.getS(),b.getW());
	}
	//getter for the variable N
	public int getN() {
		return N;
	}
	//getter for the variable S
	public int getS() {
		return S;
	}
	//getter for the variable S
	public int getW() {
		return W;
	}
	//getter for the array tiles
	public Tile[] getTiles() {
		return tiles;
	}
	//getter for the array supplies
	public Supply[]  getSupplies() {
		return supplies;
	}
	//setter for the variable N
	public void setN(int N) {
		this.N=N;
	}
	//setter for the variable S
	public void setS(int S){
		this.S=S;
	}
	//setter for the variable W
	public void setW(int W) {
		this.W=W;
	}
	//setter for the variable tiles
	public void setTiles(Tile[] t) {
		tiles=t;
	}
	//setter for the variable supplies
	public void setSupplies(Supply[] s) {
		supplies=s;
	}
	// The method createTile() is used to create the tiles of the labyrinth.
	//Firstly,this method takes a random number that is between the number given by the user and the least number of walls that must be
	//in a labyrinth in order to be a closed map that the players cannot escape.
	//The walls at the perimeter are placed with the first for loop.
	//Now the method, creates all the other walls randomly.This means that first we take a random number to know the id of the tile
	//and if we see that this tile does not have 2 walls already around it,then we check if its upper,down,right and left tile
	// do not have 2 walls either.For every one that does not have 2 walls, a possible position for our wall has been found and will be 
	//place in the ArrayList. Finally, we take another random number(randomSide) to randomly choose one of the available sides of the tile.
	//As both the tileId and the side are now found.We change the variables of the 2 tiles that have this wall in common and
	//increase the counter by 2.
	public void createTile() {
		int randomW;
		do {
			randomW= (int)(Math.random()*W);
		}while(randomW<(6*N) ); 
	    int counterOfTotalWalls=0;
	    //this for loop creates the walls in the perimeter.
	    for(int j=0 ; j <N; j++) {
	    	//for the walls in the down side of the labyrinth.
	    	tiles[j].setDown(true);
	    	counterOfTotalWalls++;
	    	//for the walls in the upper side of the labyrinth.
	    	int helper=N*(N-1);
	  		tiles[helper+j].setUp(true);
	  		counterOfTotalWalls++;
	    	//for the walls in the left side of the labyrinth
	    	tiles[(j*N)].setLeft(true);
	    	counterOfTotalWalls++;
	    	//for the walls in the right side of the labyrinth.
	    	tiles[(j*N+N-1)].setRight(true);
	    	counterOfTotalWalls++;  	
	    }
	        //for the walls that will be randomly created
	    	while(counterOfTotalWalls < randomW) {
			int randomNum=(int) (Math.random()*N*N);// the randomly chosen tile id.
			ArrayList <Integer> sides= new ArrayList<Integer>();//this arrayList will hold the sides of the tile that are available to be chosen.
			//inside this if condition goes every random tile chosen that does not have 2 walls, so as to chose in which 
			//of its side we will create the wall.
			if(tiles[randomNum].twoWalls()==false) {
				if(randomNum - N >0) { //down tile
					if(tiles[randomNum-N].twoWalls()==false && tiles[randomNum-N].getUp()==false) {
						sides.add(randomNum-N);	
					}		
				}
				if(randomNum+N < N*N) { //up tile
					if(tiles[randomNum+N].twoWalls()==false && tiles[randomNum+N].getDown()==false) {
						sides.add(randomNum+N);

					}	
				}
				if(randomNum+1 < N*N) {//right tile
					if(tiles[randomNum+1].twoWalls()==false && tiles[randomNum+1].getLeft()==false) {
					sides.add(randomNum+1);

					}	
				}
				if(randomNum-1 > 0) { // left tile
					if(tiles[randomNum-1].twoWalls()==false && tiles[randomNum-1].getRight()==false) {
						sides.add(randomNum-1);

					}
				}
				int randomSide=(int)(Math.random()*sides.size());//creates a random number in order to chose from the sides that are available
				
				//every time a size is chosen we must change the variables for not only the randomTile we chose but also for a
				//neighbouring tile.That is the reason that the counter increased by 2.
				if(sides.get(randomSide)==randomNum-N) {
					tiles[randomNum].setDown(true);
					tiles[randomNum-N].setUp(true);

				}
				else if(sides.get(randomSide)==randomNum+N){
					tiles[randomNum].setUp(true);
					tiles[randomNum+N].setDown(true);

				}
				else if(sides.get(randomSide)==randomNum+1) {
					tiles[randomNum].setRight(true);
					tiles[randomNum+1].setLeft(true);

				}
				else if(sides.get(randomSide)==randomNum-1) {
					tiles[randomNum].setLeft(true);
					tiles[randomNum-1].setRight(true);

				}
				counterOfTotalWalls+=2;
				sides.clear();
			}			
	    }
	    	
	}
	    	
	//The method createSupply() randomly creates and assigns the supplies into the tiles of the labyrinth.
	//The only restrictions for the tile that is going to hold a supply, are not to be:
	// the tiles in which either the Theseus or theMinotaur spawn in.
	//a tile that already holds a supply.
	//a tile that has a wall around it.
	public void createSupply() {
		int[] supplyArray= new int[S];//array to hold the supplies'ids so as no supply is on top of another.
		int i=0;//i is used to know how many are the ids in supplies[]. So basically it is a counter.
			while (i<S) {
				int flag=0;// if flag is 1 then the same randomNum is already in the Array.
				int randomNum=(int) (Math.random()*N*N);
				for(int j=0; j<i; j++ ) {
					if(randomNum==supplyArray[j]) {
						flag=1; //flag=1 means that this tile already has a supply. 
						break;
					}
				}
         		if(flag==0 && randomNum!=0 && randomNum!=(N*(N%2)) && (tiles[randomNum].numWalls())==0) {
					supplies[i].setsupplyTileId(randomNum);
					supplies[i].setX(randomNum%N);
					supplies[i].setY(randomNum/N);
					supplyArray[i]= randomNum;
					i++;
				}
			}
	}
	//The method createBoard simply calls the methods createTile and createSupply that fully create the variables of Board class.
	public void createBoard() {
		createTile();
		createSupply();
	}
	//The method getStringRepresentation creates the "look" of the labyrinth by creating the strings that are going to be printed.
	//In order to not check every side of a tile for a wall, this methods checks a tile for a Down and a Left wall only.
	//With this strategy we can print the labyrinth having only one different option for printing a tile that is the last tile of
	//its row. 
	//When checking if there is a left wall we also check if in the specific tile their is a supply, the minotaur or the theseus and we create
	//the necessary string.
	//Different strings are created if more than one object are in the same tile.
	//The last row of the labyrinth is created in a different loop as we do not check for up walls and we are sure that their is going
	//to be a wall in the upper side in order for a proper labyrinth to be created.
	public String[][] getStringRepresentation(int theseusTile,int minotaurTile) {
		String[][] s=new String[2*N+1][N];
		String[] stringSupplies= new String[S];
		for(int counter=0;counter<S;counter++) {
			stringSupplies[counter]="s"+ Integer.toString(counter);//this array is used to print "s" + the id of the supply 
		}
		int i,j,k;
		int flagM=0; //this counter is 0 when the Minotaur has not printed yet and 1 when it has been printed to avoid some if statements.
		int flagT=0;//this counter is 0 when the Theseus has not printed yet and 1 when it has been printed to avoid some if statements
		int helper=0;//this helper is used because of the 2*N+1 rows of the String[][].
		for( i=0; i< N ; i++,helper+=2 ) {
			for( j = 0 ; j < N; j++) {
				if(tiles[j+i*N].getDown()==true) {// checking if there is a Down Wall.
					if((j+i*N)% N==(N-1)) { //checking if this down wall is in a last tile of a row.
						s[helper][j]="+---+";

					}
					else {
				
						s[helper][j]="+---";
					}
				}
				else {//so their is no Down Wall
					if((j+i*N)% N==(N-1)) {//if it is the last tile of the row.
						s[helper][j]="+   +";
					}
					else {
				
						s[helper][j]="+   ";
					}
				}
				if(tiles[j+i*N].getLeft()==true) {//checking if there is a Left Wall.
				int hasNothing=0;// if there is nothing inside a tile we will print tabs only.
				if(flagT==0) { //checking if the theseus is already in the map
				if(theseusTile==(j+i*N)) {
					if((j+i*N)%N==(N-1)) {//checking if it is the last tile of a row.
						s[helper+1][j]="| T |";
						flagT=1;
						hasNothing+=1;
					}
					else {//so it is not the last tile of the row
						s[helper+1][j]="| T ";
						flagT=1;
						hasNothing+=1;
					}	
				  }
				}
				if(flagM==0) {//checking if the Minotaur is already in the map
				if(minotaurTile==(j+i*N)) {
					if((j+i*N)%N==(N-1)) {//if it is the last tile of the row.
						s[helper+1][j]="| M |";
						flagM=1;
						hasNothing+=1;
					}
					else {
						s[helper+1][j]="| M ";
						flagM=1;
						hasNothing+=1;
					}	
				} 
				}
				for(int counter=0;counter<S;counter++) {
					if(supplies[counter].getsupplyTileId()==(j+i*N)) {// we check if their is as supply
						if((j+i*N)%N==(N-1)) {//if it is the last tile of the row.
							if(minotaurTile==(j+i*N)) { //checking if both the minotaur and a supply are in a tile together.
							s[helper+1][j]="|M"+stringSupplies[counter]+"|";
							}
							else if(theseusTile==(j+i*N)) {
							s[helper+1][j]="|T"+stringSupplies[counter]+"|";
							}
							else {
							s[helper+1][j]="|"+stringSupplies[counter]+" |";
							hasNothing+=1;
							}
						}
						else {
							if(minotaurTile==(j+i*N)) {//checking if both the minotaur and a supply are in a tile together.
							s[helper+1][j]="|M"+stringSupplies[counter];
							}
							else if(theseusTile==(j+i*N)) {//checking if both the theseus and a supply are in a tile together.
							s[helper+1][j]="|T"+stringSupplies[counter];
							}
							else {
							s[helper+1][j]="|"+stringSupplies[counter]+" ";
							hasNothing+=1;
								
							}
							}	
					}

				 }
				 if(hasNothing==0) { //so if it has nothing but a left wall.
					if((j+i*N)%N==(N-1)) {//if it is the last tile of the row.
						s[helper+1][j]="|   |";
					}
					else {
						s[helper+1][j]="|   ";
					}	
				 }
				
				
				}
				else {
			 		int hasNothing2=0;
					if(flagT==0) {
					if(theseusTile==(j+i*N)) {
						if((j+i*N)%N==(N-1)) {//if it is the last tile of the row.
							s[helper+1][j]="  T |";
							flagT=1;
							hasNothing2+=1;
						}
						else {
							s[helper+1][j]="  T ";
							flagT=1;
							hasNothing2+=1;
						}	
					}
					}
					if(flagM==0) {
					if(minotaurTile==(j+i*N)) {
						if((j+i*N)%N==(N-1)) {//if it is the last tile of the row.
							s[helper+1][j]="  M |";
							flagM=1;
							hasNothing2+=1;
						}
						else {
							s[helper+1][j]="  M ";
							flagM=1;
							hasNothing2+=1;
						}	
					}
					}
					for(int counter=0;counter<S;counter++) {
						if(supplies[counter].getsupplyTileId()==(j+i*N)) {
							if((j+i*N)%N==(N-1)) {//if it is the last tile of the row.
								if(minotaurTile==(j+i*N)) {//checking if both the minotaur and a supply are in a tile together.
								s[helper+1][j]=" M"+stringSupplies[counter]+"|";	
								}
								else if(theseusTile==(j+i*N)) {//checking if both the theseus and a supply are in a tile together.
								s[helper+1][j]=" T"+stringSupplies[counter]+"|";
								}
								else {
								s[helper+1][j]=" "+stringSupplies[counter]+" |";
								hasNothing2+=1;	
									
								}
								
							}
							else {
								if(minotaurTile==(j+i*N)) {//checking if both the minotaur and a supply are in a tile together.
								s[helper+1][j]=" M"+stringSupplies[counter]+"";
								}
								else if(theseusTile==(j+i*N)) {//checking if both the theseus and a supply are in a tile together.
								s[helper+1][j]=" T"+stringSupplies[counter]+"";
								}
								else {
								s[helper+1][j]=" "+stringSupplies[counter]+" ";
								hasNothing2+=1;	
								}
							}
						}

					}
					if(hasNothing2==0) {//if it has absolutely nothing in it.
						if((j+i*N)%N==(N-1)) {//if it is the last tile of the row.
							s[helper+1][j]="    |";
						}
						else {
							s[helper+1][j]="    ";
						}
					}
			
			}	
		}
	for(k=0;k<N;k++) {// for the last upper wall
		if((k%N)==N-1) {
			s[2*N][k]="+---+";
		}
		else {
			s[2*N][k]="+---";
		}
	}
		
		
    }	
		return s;
 }
	


}
