import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.awt.event.*;

public class Main {
	public static  int round=0; 	//the round of the game
	public static final int maxRounds=100;//the number of maximum rounds.
	//the constructor of the class
	public Main() {
		round=1; 
	}
	//setter for the variable round
	static public void setRound(int round1) {		
		round =  round1;
	}
	//getter for the variable round.
	public int getRound() {					//GETTER
		return round;
	}
	
public static void main(String[] args) {
	//this is the main frame of the game
	JFrame mainFrame=new JFrame("MAIN FRAME");
	
	
	
	
	//we create the board
	int N=15;
	Board board=new Board(N,10,140);
	board.createBoard();
	
	//create the gui board, with BorderLayout and adding the board Panel of BoardGUI class to the object
	BoardGUI GamePanel=new BoardGUI(board,0,112);
	GamePanel.setLayout(new BorderLayout());
	GamePanel.add(BorderLayout.CENTER,GamePanel.getboardPanel());
	
	
	
	//create a panel that will have the game buttons
	JPanel playbutton=new JPanel();
	playbutton.setLayout(new BoxLayout(playbutton,BoxLayout.Y_AXIS));
	
	//play button 
	JButton play1=new JButton("PLAY ");
	//an empty label 
	JLabel empty=new JLabel(" ");
	
	JPanel middle=new JPanel();
	
	middle.add(play1);
	playbutton.add(middle);
	playbutton.add(empty);
	play1.setVisible(false); //we set the playbutton invisible
	mainFrame.getContentPane().add(BorderLayout.SOUTH,playbutton);//add playbutton panel on the main Frame
	
	
	//we create the MainWindow
	MainWindow basic=new MainWindow(GamePanel,0,0,0);
	mainFrame.add(basic);
	basic.getGenerateBoardButton().setFocusable(false);
	
	
	
	

	

	mainFrame.setSize(850, 850);  
    mainFrame.setLocationRelativeTo(null);  
    mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
    mainFrame.setVisible(true); 
	printBoard(-1,-1,board);
	
	
	
	Player player1=new Player();//this will be inherited by minmax or heuristic
	
	
	Player player2 = new Player();
	
	
	//By pressing the play button  a new frame pops up and tells the player to choose between heuristic and minmax
	//the random player does not support a lot of methods so is not i the options
	play1.addActionListener(new ActionListener(){  
		public void actionPerformed(ActionEvent e) {
			JFrame choosePlayer=new JFrame("Choose Player");
			choosePlayer.setLayout(new BorderLayout());
			choosePlayer.setSize(new Dimension(250,125));
			choosePlayer.setVisible(true);
			choosePlayer.setLocationRelativeTo(null);
			
			JLabel choose=new JLabel("       Choose the type of player:");
			choosePlayer.getContentPane().add(BorderLayout.NORTH,choose);
			JPanel options=new JPanel();
			JButton MinMaxPlayer=new JButton("MinMaxPlayer");
			MinMaxPlayer.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					basic.getGenerateBoardButton().setVisible(true);//set the generateboard button visible
					player1.child=true;
					choosePlayer.dispose();
					play1.setVisible(false);
					//player1=new MinMaxPlayer();
				}
				
			});
			JButton HeuristicPlayer=new JButton("HeuristicPlayer");
			HeuristicPlayer.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					basic.getGenerateBoardButton().setVisible(true);
					player1.child=false;
					choosePlayer.dispose();
					play1.setVisible(false);
				}
			});
			options.add(MinMaxPlayer);
			options.add(HeuristicPlayer);
			options.setFocusable(false);
			choosePlayer.getContentPane().add(BorderLayout.CENTER,options);
			
			
			
		}
		
	}); 
	
	
	//heuristicChosen=player1;
	player1.setBoard(board);// set the board of the two players to be the board of the game
	player2.setBoard(board);
	player1.setPlayerId(1);	//set player id
	
	
	
	
	
	player2.setPlayerId(2);	
	player1.setX(0);//setting the starting positions
	player1.setY(0);
	int player1TileIdHelp = player1.getTile(player1.getX(), player1.getY()).getTileId();
	
	//MinMaxPlayer player3=new MinMaxPlayer();
	
	
	MinMaxPlayer minChosen=new MinMaxPlayer(player1);
	HeuristicPlayer heuristicChosen=new HeuristicPlayer(player1);
	
	
	//player1.setCurrentPos(player1TileIdHelp);
	minChosen.setCurrentPos(player1TileIdHelp);
	heuristicChosen.setCurrentPos(player1TileIdHelp);

	player2.setX(N/2);
	player2.setY(N/2);
	int player2TileIdHelp = player2.getTile(player2.getX(), player2.getY()).getTileId();
	
	//player1.setOtherPlayer(player2TileIdHelp);
	minChosen.setOtherPlayer(player2TileIdHelp);
	heuristicChosen.setOtherPlayer(player2TileIdHelp);
	
	
	basic.getGenerateBoardButton().setVisible(false);
	
	play1.setFocusable(false);
	
	//Add action to the UP key, in order to see the player moving

	JRootPane rootPane=mainFrame.getRootPane();
	
	rootPane.getInputMap().put(KeyStroke.getKeyStroke("UP"),"moveGui");
	play1.setVisible(true);
	
		Action moveGui=new AbstractAction() {
		

			public void actionPerformed(ActionEvent e){
				//while(round<=100) {
				if(round==100) { //if the round==100 the game is over
					rootPane.getInputMap().remove(KeyStroke.getKeyStroke("UP"));
					rootPane.getActionMap().clear(); 
					play1.setVisible(false);
					JFrame finalFrame=new JFrame();
					finalFrame.setLayout(new FlowLayout());
					JLabel winner=new JLabel("IT  IS  A  TIE!");
					winner.setFont(new Font("Serif", Font.PLAIN, 33));
					JButton exit=new JButton("EXIT GAME");
					finalFrame.add(winner);
					finalFrame.add(exit);
					finalFrame.setSize(new Dimension(250,125));
					finalFrame.setVisible(true);
					finalFrame.setLocationRelativeTo(null);
					finalFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
					exit.setFocusable(false);
					mainFrame.removeAll();
					exit.addActionListener(new ActionListener(){  //exit button
						public void actionPerformed(ActionEvent e){
						System.exit(0);	
						}
					});
						
				
				}
				int helper=round;
				int player1Move;	//arrays in order to save the  board of move() method
				int[] player2Move;
				System.out.println("ROUNDS:"+ helper +" MAX ROUNDS:"+maxRounds);
				int player1TileId ;
				if(player1.child) {//player1.child tells us if the player is minmax or heuristic
					player1TileId=minChosen.getTile(minChosen.getX(),minChosen.getY()).getTileId();//MINMAX
				}
				else {
					player1TileId=heuristicChosen.getTile(heuristicChosen.getX(),heuristicChosen.getY()).getTileId();//HEURISTIC
				}
				
				int player2TileId = player2.getTile(player2.getX(), player2.getY()).getTileId();
				
				
				printBoard(player1TileId,player2TileId,board);//we print the board to compare with the gui
				
				//player1.setOtherPlayer(player2TileId);
				minChosen.setOtherPlayer(player2TileId);
				heuristicChosen.setOtherPlayer(player2TileId);
				
				//player1.setCurrentPos(player1TileId);// CURRENT POS HELPING THE EVALUATION
				minChosen.setCurrentPos(player1TileId);
				heuristicChosen.setCurrentPos(player1TileId);
				
				//player1Move = player1.getNextMove(player1TileId,player2TileId);		//the players move on the board.
				if(player1.child) {
				player1Move=minChosen.getNextMove(player1TileId,player2TileId);
				}
				else {
					player1Move=heuristicChosen.getNextMove(player1TileId);
				}
				
		        player2Move = player2.move(2);
		      //create the new board that demonsatrates the move
				BoardGUI gameboard=new BoardGUI(board,player1Move,player2Move[0]);
		
			System.out.println("HERE");
			
			mainFrame.remove(basic);//remove the old mainWindow
			MainWindow window1=new MainWindow(gameboard,player1.getScore(),0,helper);
			window1.getResetButton().setVisible(false);
			mainFrame.add(window1);
			
			mainFrame.validate();
			window1.getGenerateBoardButton().setVisible(false);
			gameboard.getboardPanel().setVisible(true);
			//getPlayButton().setVisible(true);
	       // window1.getResetButton().setVisible(true);
	       // window1.getGenerateBoardButton().setVisible(false);
	        board.count=0;
	       
	       if(player1.child) {
	    	   player1.setScore(minChosen.getScore());
	       }
	       else {
	    	   player1.setScore(heuristicChosen.getScore());
	       }
	        if(player1.getScore() == board.getS()) {//if the score of the player is equal to the number of supplies the player wins.
				System.out.println("THESEUS WON, GOOD JOB!!!");
				System.out.println("=============================THESEUS STATISTICS=============================");
				//player1.statistics(round);
				if(player1.child) {
					minChosen.statistics(round);
				}
				else {
					heuristicChosen.statistics(round);
				}
				//final popup frame
				JFrame finalFrame=new JFrame();
				finalFrame.setLayout(new FlowLayout());
				JLabel winner=new JLabel("GAME OVER, THESEUS WON!!!");
				winner.setFont(new Font("Serif", Font.PLAIN, 33));
				JButton exit=new JButton("EXIT GAME");
				play1.setVisible(false);
				
				finalFrame.add(winner);
				finalFrame.add(exit);
				finalFrame.setSize(new Dimension(250,125));
				finalFrame.setVisible(true);
				finalFrame.setLocationRelativeTo(null);
				finalFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
				
				mainFrame.removeAll();
				exit.setFocusable(false);
				exit.addActionListener(new ActionListener(){  
			//basic.setActionPlayButton(mainFrame, basic);
			
			public void actionPerformed(ActionEvent e){
			System.exit(0);	
			}
			});
				
			}
				
			else if(player1Move == player2.getTile(player2.getX(),player2.getY()).getTileId()) {//if THESEUS is in the same tile with minotaur, theseus loses
				System.out.println("MINOTAURUS WON!!!");
				System.out.println("=============================THESEUS STATISTICS=============================");
				//player1.statistics(round);
				if(player1.child) {
					minChosen.statistics(round);
				}
				else {
					heuristicChosen.statistics(round);
				}
				JFrame finalFrame=new JFrame();
				finalFrame.setLayout(new FlowLayout());
				JLabel winner=new JLabel("GAME OVER, MINOTAURUS WON!!!");
				winner.setFont(new Font("Serif", Font.PLAIN, 33));
				JButton exit=new JButton("EXIT GAME");
				
				play1.setVisible(false);
				
				finalFrame.add(winner);
				finalFrame.add(exit);
				finalFrame.setSize(new Dimension(550,125));
				finalFrame.setVisible(true);
				finalFrame.setLocationRelativeTo(null);
				finalFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
				
				mainFrame.removeAll();
				exit.setFocusable(false);
				exit.addActionListener(new ActionListener(){  
			
			
					public void actionPerformed(ActionEvent e){
						System.exit(0);	
						}
					});
				//break;
				}
	      
			System.out.println("THESEUS SCORE: "+player1.getScore());
			//player2Move = player2.move(2);
			if(player2Move[0] == player1.getTile(player1.getX(),player1.getY()).getTileId()) {
				System.out.println("MINOTAURUS WON!!!");
				printBoard(player1Move,player2Move[0],board);				////we print the board one extra time when Theseus and Minotaur move to the same tile
				System.out.println("GAME OVER!!");
				System.out.println("=============================THESEUS STATISTICS=============================");
				//player1.statistics(round);
				if(player1.child) {
					minChosen.statistics(round);
				}
				else {
					heuristicChosen.statistics(round);
				}
				JFrame finalFrame=new JFrame();
				finalFrame.setLayout(new FlowLayout());
				JLabel winner=new JLabel("GAME OVER, MINOTAURUS WON!!!");
				winner.setFont(new Font("Serif", Font.PLAIN, 33));
				JButton exit=new JButton("EXIT GAME");
				
				play1.setVisible(false);
				
				finalFrame.add(winner);
				finalFrame.add(exit);
				finalFrame.setSize(new Dimension(250,125));
				finalFrame.setVisible(true);
				finalFrame.setLocationRelativeTo(null);
				finalFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
				
				mainFrame.removeAll();
				exit.setFocusable(false );
				exit.addActionListener(new ActionListener(){  
					//basic.setActionPlayButton(mainFrame, basic);
			
					public void actionPerformed(ActionEvent e){
						System.exit(0);	
						}
					});
				//break;
				}
				
			round++;
			System.out.print("PLAYER 1 MOVED TO "+player1Move);
			System.out.println(", PLAYER 2 MOVED TO "+player2Move[0]);
		//}
			if(round==maxRounds+1){
				System.out.println("IT IS A TIE");
				System.out.println("=============================THESEUS STATISTICS=============================");
				//player1.statistics(maxRounds-1);
				if(player1.child) {
					minChosen.statistics(round-1);
				}
				else {
					heuristicChosen.statistics(round-1);
				}
			}
			}
		};
		basic.getGenerateBoardButton().addActionListener(new ActionListener(){  
			
			//we add action to up key, all the above is the action
			public void actionPerformed(ActionEvent e){
				//play1.setVisible(true);
				
				basic.getGenerateBoardButton().setVisible(false);
				
				rootPane.getActionMap().put("moveGui",moveGui );  
				
				
				
			}
		
		});
		
		
	 

		
		
	//System.out.println("I AM HERE");
	    
		

}
public static void printBoard( int theseusTile, int minotaurTile,Board board) {
	String[][] gameBoard= board.getStringRepresentation(theseusTile,minotaurTile);
	int t,p;
	for( t=2*board.getN();t>=0;t--) {
		{	
		for(p=0;p<board.getN();p++) {
		System.out.print(gameBoard[t][p]);
		}	
		//System.out.println();
		System.out.println();
		}
   } 
		
		
	

}
}