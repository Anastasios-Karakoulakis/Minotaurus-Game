/*
�������������: ������ �������� , ���:10107, MAIL:gdgkyzis@ece.auth.gr, ��������:6978722050.
�������������: ������������ ���������� , ���:10055, MAIL:karakoul@ece.auth.gr, ��������:6978496539.
�������������: ����� ������, ���:10174, MAIL:mpsathas@ece.auth.gr, ��������:6943491245.
*/
// This class is created so as our game to be played. It counts the rounds of the game.In its round players move and the labyrinth is printed
//in the console of the user.
public class Game {
	public static  int round; 	//the round of the game
	public static final int maxRounds=100;//the number of maximum rounds.
	//the constructor of the class
	public Game() {
		round=1; 
	}
	//setter for the variable round
	static public void setRound(int round1) {		
		round =  round1;
	}
	//getter for the variable round.
	public int getRound() {					//GETTER
		return round;
	}
	//the main of the project runs the game given the arguments needed according to the instructions.
	static public void main( String[]  args) {
		int N=15;
		Board board = new Board(N,4,(3*N*N+1)/3);//we create a board.
		board.createBoard();
		
		Player player1 = new Player();//we create 2 players.
		Player player2 = new Player();
		player1.setBoard(board);// set the board of the two players to be the board of the game
		player2.setBoard(board);
		player1.setPlayerId(1);	//set player id
	
		player2.setPlayerId(2);	
		player1.setX(0);//setting the starting positions
		player1.setY(0);
		player2.setX(N/2);
		player2.setY(N/2);
		
		int[] player1Move;	//arrays in order to save the  board of move() method
		int[] player2Move;
		
		while( round < maxRounds+1) {	//if the round is 100 the game ends 
			System.out.println("ROUNDS:"+ round+" MAX ROUNDS:"+maxRounds);
			int player1TileId = player1.getTile(player1.getX(), player1.getY()).getTileId();
			int player2TileId = player2.getTile(player2.getX(), player2.getY()).getTileId();
			printBoard(player1TileId,player2TileId,board);
			player1Move = player1.move(1);		//the players move on the board.
			
		
			if(player1.getScore() == board.getS()) {//if the score of the player is equal to the number of supplies the player wins.
				System.out.println("THESEUS WON, GOOD JOB ");
				break;
			}
			else if(player1Move[0] == player2.getTile(player2.getX(),player2.getY()).getTileId()) {//if THESEUS is in the same tile with minotaur, theseus loses
				System.out.println("THESEUS LOST, GAME OVER!!");
				break;
			}
			System.out.println("THESEUS SCORE: "+player1.getScore());
			player2Move = player2.move(2);
			if(player2Move[0] == player1.getTile(player1.getX(),player1.getY()).getTileId()) {
				System.out.println("IT WAS AT THIS MOMENT THAT HE KNEW, HE LOST THE GAME. MINOTAURUS WON");
				 printBoard(player1Move[0],player2Move[0],board);				////we print the board one extra time when Theseus and Minotaur move to the same tile
				 System.out.println("GAME OVER!!");
				break;
			}
				round++;
			
			System.out.print("PLAYER 1 MOVED TO "+player1Move[0]);
			System.out.println(", PLAYER 2 MOVED TO "+player2Move[0]);
		}
			if(round==maxRounds+1)System.out.println("IT IS A TIE");
	}
	//This method is used to print the labyrinth in every single round.
	//As the [0][0] tile is not the upper left, the for statement use the correct arithmetics to print the labyrinth correctly.
	//using the String[][] of the getStringRepresentation.
	public static void printBoard( int theseusTile, int minotaurTile,Board board) {
		String[][] gameBoard= board.getStringRepresentation(theseusTile,minotaurTile);
		int t,p;
		for( t=2*board.getN();t>=0;t--) {
			{	
			for(p=0;p<board.getN();p++) {
			System.out.print(gameBoard[t][p]);
			}	
			//System.out.println();
			System.out.println();
			}
	   } 
			
			
		
	}
	
}