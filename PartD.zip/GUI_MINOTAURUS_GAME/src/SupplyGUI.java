import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.*;

/*
 * the gui class of supply
 */
public class SupplyGUI extends JLabel {
	ImageIcon supply;
	BoardGUI board;
	HashMap<Supply,Integer> suppliesPos;
	Supply[] supplies;
	SupplyGUI(BoardGUI board){
		super();
		
		
		//supplies=board.getgameBoard().getSupplies();
		
		
		this.board=board;
			
		supply=new ImageIcon(this.getClass().getResource("/SWORD3.png"));
	}
	//setters
	public void setsupply(ImageIcon supply) {
		this.supply=supply;
	}
	public void setboard(BoardGUI board) {
		this.board=board;
	}
	public void setsuppliesPos(HashMap<Supply,Integer> suppliesPos) {
		this.suppliesPos=suppliesPos;
	}
	public void setsupplies(Supply[] supplies) {
		this.supplies=supplies;
	}
	
	//getters
	public ImageIcon getsupply() {
		return supply;
	}
	public BoardGUI getboard() {
		return board;
	}
	public HashMap<Supply,Integer> getsuppliesPos(){
		return suppliesPos;
	}
	
	//setting the icon
	public void addSupply() {
		this.setIcon(supply);
	
	}

}
