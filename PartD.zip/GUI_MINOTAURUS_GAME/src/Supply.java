
/* This class constructed in a way that creates supply objects */
public class Supply
{
 
   private int supplyId; //id of each supply
   private int x;        //x-coordinate of the tile which has supply
   private int y;        //y-coordinate of the tile which has supply 
   private int supplyTileId;//id of the tile which has supply

   //this non-argument constructor sets initial values in our variables 
 public  Supply()  //
 {
       supplyId=0;
       x=0;
       y=0;
       supplyTileId=0;
       }
 //this constructor takes as argument the supply Id of every supply
 //this constructor initialises every supply object
 public Supply(int supplyId) 
 {
     this.supplyId=supplyId;
       x=0;
       y=0;
       supplyTileId=0;
 }
 //This constructor that takes as an argument another supply and creates same object
 public  Supply(Supply s) {
     supplyId=s.getsupplyId();
     x=s.getX();
     y=s.getY();
     supplyTileId=s.getsupplyTileId();
 }
 //setter for the variable supplyId
   public void setsupplyId(int sid) { 
       supplyId = sid;
      }
//setter for the variable supplyTiledId
   public void setsupplyTileId(int stid){
       supplyTileId = stid;
      }
//getter for the variable supplyId
   public int getsupplyId()
   { 
       return supplyId;
      }
 //getter for the variable supplyTileId
   public int getsupplyTileId()
   {
       return supplyTileId;
    }

 //setter for the variable x
   public void setX(int x)
   {
      this.x = x;
      }
 //getter for the variable x
   public int getX(){
       return x;
      }
 //setter for the variable y
   public void setY(int y){
       this.y = y;
      }
 //getter for the variable y
   public int getY(){
       return y;
   }



}
