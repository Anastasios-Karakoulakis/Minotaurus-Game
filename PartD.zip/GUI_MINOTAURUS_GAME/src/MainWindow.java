import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
/*
 * This class is one of the main composers of the gui, it holds some of the main buttons
 * and the labels about the score.
 */
public class MainWindow extends JPanel {
	
	static int counter=0;
	JPanel south;
	JPanel east;
	JPanel west;
	JPanel north;
	
	BoardGUI CentergameBoard;
	
	
	JLabel theseusScore;
	JLabel minoScore;
	JLabel round;
	
	//JButton play;
	JButton quit;
	JButton generateBoard;
	
	
	
	JButton reset;
	
	
	
	
	/*JLabel minmaxLabel;
	JLabel heuristicLabel;
	JPanel minmaxOption;
	JPanel heuristicOption;*/
	
	MainWindow(BoardGUI gameBoard,int theseusScore,int minoScore, int Round){
		super(new BorderLayout());
		createBorders();
		
		
		CentergameBoard=gameBoard;
		this.add(BorderLayout.CENTER,CentergameBoard.getboardPanel());
		CentergameBoard.getboardPanel().setVisible(false);
		
		
		createScoreLabels(theseusScore,minoScore,Round);
		createButtons();
		addActionListenersToButton();
		reset.setVisible(false);
		
		
		
		
		
		
		
		
		
		
	}
	//setters only the needed
	public void setCentergameBoard(BoardGUI gameBoard) {
		this.CentergameBoard=gameBoard;
		this.add(CentergameBoard);
	}
	public void settheseusScore(int score) {
		theseusScore.setText("THESEUS SCORE :  "+Integer.toString(score));
	}
	public void setminoScore(int score) {
		minoScore.setText("MINOTAURUS SCORE :  "+Integer.toString(score));
	}
	public void setround(int round) {
		this.round.setText("ROUND :  "+Integer.toString(round));
	}
	
	//getters only the needed
	public JButton getPlayButton() {
		return null;
	}
	public JButton getQuitButton() {
		return quit;
	}
	public JButton getGenerateBoardButton() {
		return generateBoard;
	}
	public JButton getResetButton() {
		return reset;
	}
	/*
	 * method that create the buttons of the class 
	 */
	public void createButtons() {
		//play=new JButton(" PLAY ");
		//play.setVisible(false);
		
		quit=new JButton(" QUIT ");
		quit.setFocusable(false );
		generateBoard=new JButton(" GENERATE BOARD ");
		reset=new JButton(" RESET GAME ");
		reset.setVisible(false);
		reset.setFocusable(false);
		JPanel buttons=new JPanel();
		//buttons.add(play);
		buttons.add(generateBoard);
		buttons.add(quit);
		buttons.add(reset);
		south.add(buttons);
		createEmptyLabels(2,south);//we use empty labels 
	}
	//adding layout Managers, colors and the Title of the game
	public void createBorders() {
		south=new JPanel();
		south.setLayout(new BoxLayout(south,BoxLayout.Y_AXIS));
		
		
		east=new JPanel(new BorderLayout());
		
		west=new JPanel();
		west.setLayout(new BoxLayout(west,BoxLayout.Y_AXIS));
		west.setBorder(BorderFactory.createLineBorder(Color.GRAY, 3, true));
		west.setBackground(Color.LIGHT_GRAY);
		
		north=new JPanel();
		JLabel title=new JLabel(new ImageIcon(this.getClass().getResource("/GAMELABEL6.png")));
		north.add(title);
		
		this.add(BorderLayout.SOUTH,south);
		this.add(BorderLayout.EAST,east);
		this.add(BorderLayout.WEST,west);
		this.add(BorderLayout.NORTH,north);
		
	}
	//empty label creator
	public void createEmptyLabels(int num,JComponent item) {
		for(int i=0;i<num;i++) {
			JLabel helper=new JLabel(" ");
			//helper.setIcon(new ImageIcon(this.getClass().getResource("/wall2.4.jpg")));
			item.add(helper);
		}
	}
	//score labels
	public void createScoreLabels(int theseus,int Mino,int Round) {
		theseusScore=new JLabel("Theseus Score :   "+Integer.toString(theseus));
		theseusScore.setFont(new Font("Serif", Font.PLAIN, 25));
		
		
		minoScore=new JLabel("Minotaurus Score :  "+Integer.toString(Mino)+" ");
		minoScore.setFont(new Font("Serif", Font.PLAIN, 25));
		
		
		round=new JLabel(new ImageIcon(this.getClass().getResource("/ROUND5.png")));
		round.setText(" "+Integer.toString(Round));
		round.setFont(new Font("Serif", Font.PLAIN, 33));
		
		
	
		west.add(round);
		createEmptyLabels(15,west);
		west.add(theseusScore);
		createEmptyLabels(1,west);
		west.add(minoScore);
	}
	//adding actionListeners to the buttons
	public void addActionListenersToButton() {
		//QUIT BUTTON
		this.getQuitButton().addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){
				JFrame closeFrame=new JFrame();
				JPanel closepanel=new JPanel();
				closeFrame.setSize(200, 100);  
				closeFrame.setLocationRelativeTo(null);  
				//closeFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
				closeFrame.setVisible(true); 
				
				JButton closeButton=new JButton("YES");
				JButton nocloseButton=new JButton("NO");
				closeButton.addActionListener(new ActionListener(){  
					public void actionPerformed(ActionEvent e){
						System.exit(0);
					}
					});
				nocloseButton.addActionListener(new ActionListener(){  
					public void actionPerformed(ActionEvent e){
						closeFrame.dispose();
					}
					});
				JLabel sure=new JLabel("  Are you sure you want to exit?  ");
				closepanel.add(sure);
				closepanel.add(closeButton);
				closepanel.add(nocloseButton);
				closeFrame.add(closepanel);
				
			}  
		});
		//GENERATE BOARD
		this.getGenerateBoardButton().addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
		           CentergameBoard.getboardPanel().setVisible(true);
		           getGenerateBoardButton().setVisible(false);
		          // getPlayButton().setVisible(true);
		           getResetButton().setVisible(false);
		           JFrame message=new JFrame("MESSAGE");
		           message.setLayout(new BorderLayout());
		           message.setSize(350, 100);  
		           message.setLocationRelativeTo(null);  
		           
		           message.setVisible(true); 
		           JLabel move=new JLabel("   PRESS UP KEY, TO SEE THE PLAYER MOVING");
		           JPanel helperPanel=new JPanel();
		           
		           JButton ok=new JButton("OK");
		           helperPanel.add(move);
		           helperPanel.add(ok);
		           message.add(helperPanel);
		           ok.addActionListener(new ActionListener() {
		        	   public void actionPerformed(ActionEvent arg0) {
		        		   message.dispose();
						
					}
		           });
		           
		}  
		});
		
		
	}

}
