
import java.util.HashMap;

public class DataContainer {
	Boolean minotaurus;
	Boolean supply;
	HashMap<Integer,Boolean> walls;
	int TileId;
	//Constructors
	DataContainer(){
		minotaurus=false;
		supply=false;
		walls= new HashMap<Integer,Boolean>();
		TileId=-1;
	}
	
	DataContainer(Boolean minotaurus,Boolean supply, HashMap<Integer,Boolean> walls,int TileId){
		this.minotaurus=minotaurus;
		this.supply=supply;
		this.walls=walls;
		this.TileId=TileId;
		
	}
	//setters
	public void setMinotaurus(Boolean minotaurus) {
		this.minotaurus=minotaurus;
		
	}
	public void setSupply(Boolean supply) {
		this.supply=supply;
		
	}
	public void setWalls(HashMap<Integer,Boolean> walls) {
		this.walls=walls;
		
	}
	public void setTileId(int TileId) {
		this.TileId=TileId;
	}
	//getters
	public Boolean getMinotaurus() {
		return minotaurus;
	}
	public Boolean getSupply() {
		return supply;
	}
	public HashMap<Integer,Boolean> getWalls(){
		return walls;
	}
	public int getTileId() {
		return TileId;
	}
	/*
	 * this method calls the other three methods to collect the data about the supply,Minotaurus and the walls
	 */
	public void DataCollector(Board board, int otherPlayer) {
		supplyFinder(board);
		minotaurusSearch(otherPlayer);
		wallsInitializer(board);
	}

	/*
	 *this method finds the supplies, checks if the Tile Id of the DataContainer is the same with any supply of supplies[ ]
	 *if it finds any supply, it returns true
	 */
    private void supplyFinder(Board board) {
    	Boolean supplySearch=false;
    	for(Supply helpSupply:board.getSupplies()) {
    		if(helpSupply.getsupplyTileId()==TileId) {
    			supplySearch=true;
    			break;
    		}
    	}
    	supply=supplySearch;							    	
    }
	

    /*
     * is similar to supplyFinder, but it searches for the minotaurus that has Tile Id= otherPlayer
     * the otherPlayer variable is passed as argument
     */
    private void minotaurusSearch(int otherPlayer){
    	Boolean isMino=false;
    	if(TileId==otherPlayer) {
    		isMino=true;
    	}
    	minotaurus=isMino;									
    														
    	
    }
	
	
    /*
     * this method finds with the help of the getWall( ), all the walls of the Tile that we examine
     * all the informations about the walls are stored in a HashMap that has as key the direction {1,3,5,7} and 
     * as value the Boolean expression about the existence of a wall 
     */
	private void wallsInitializer(Board board) {
		for(int i=1;i<8;i+=2) {
			getWall(i,board);
		}
		
	}
	
   /*
    *method that returns the wall, for direction i
	*we will store the data about the walls for one tile, in the hashMap with key the direction and value a Boolean about the wall
    */
    private void getWall(int direction, Board board) {
    	switch(direction) {
    		case 1:
    			walls.put(direction,board.getTiles()[TileId].getUp());
    			break;
    		case 3:
    			walls.put(direction,board.getTiles()[TileId].getRight());
    			break;
    		case 5:
    			walls.put(direction,board.getTiles()[TileId].getDown());
    			break;
    		case 7:
    			walls.put(direction,board.getTiles()[TileId].getLeft());
    			break;
    		default: walls.put(direction,false);
    		break;
    	}
    	
    }
//
}
